import java.util.Iterator;
import org.graphstream.graph.Edge;
import org.graphstream.graph.Graph;
import org.graphstream.graph.implementations.MultiGraph;
import java.awt.Graphics;
import java.io.Writer;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.time.Instant;
import java.text.Format;
import java.util.Dictionary;
import javax.swing.JComponent;
import java.util.Hashtable;
import java.text.DecimalFormat;
import java.awt.Dimension;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Font;
import java.awt.LayoutManager;
import javax.swing.UIManager;
import java.awt.Color;
import java.io.IOException;
import java.io.FileReader;
import java.awt.Component;
import javax.swing.JSlider;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JFrame;

class sNode
{
    String id;
    int visited;
    int flag;
    sNode next;
    sNode prev;
    
    sNode() {
        this.flag = 0;
    }
}
class Rpair
{
    String id1;
    String id2;
    int done;
    Rpair next;
}

class PO
{
    String id1;
    String id2;
    int visited;
    PO next;
}
class plist
{
    int name;
    sNode begin;
    plist next;
}
class Node
{
    String id;
    int priority;
    Node next;
}
class NFRWeight
{
    String id;
    float val;
    NFRWeight next;
}
class MC
{
    BC Blist;
    int CEdge;
    MC next;
}
class MacroWeight
{
    String id1;
    String id2;
    float val;
    MacroWeight next;
}
class FRDep
{
    String id;
    int val;
    FRDep next;
}
class Edge2
{
    String id1;
    String id2;
    Edge2 next;
}
class Edge1
{
    String id1;
    String id2;
    int value;
    Edge1 next;
}
class DrawNode
{
    String name;
    int indegree;
    int visited;
    int x;
    int y;
    DrawNode next;
}
class BC
{
    String Nid;
    FRDep begin;
    BC next;
}
public class PartialOrder extends JFrame
{
    static plist rlist;
    static Node FR;
    static Node NFR;
    static Edge1 E_FN;
    static Edge1 E_NN;
    static Edge2 E_FF;
    static BC bcHead;
    static MC mcHead;
    static Rpair root;
    static PO proot;
    static Node LNFR1;
    static Node LNFR2;
    static DrawNode droot;
    static int countNFR;
    static int countFR;
    static int choice;
    static double w1;
    static double w2;
    static JFrame frame1;
    static JLabel[] NFRlabels;
    static JTextField[] NFRPriority;
    static JLabel label1;
    static JLabel label2;
    static JLabel label3;
    static JLabel label4;
    static JLabel label5;
    static JLabel label6;
    static JLabel label7;
    static JLabel label8;
    static JLabel label9;
    static final JButton savePriority;
    static final JRadioButton conflict;
    static final JRadioButton priority;
    static final JRadioButton both;
    static final JRadioButton both2;
    static final JRadioButton nc;
    static final JButton submit;
    static final JButton generate;
    static final JButton viewgraph;
    static JTextArea textOrder1;
    static JScrollPane scrollPane1;
    static JTextArea textOrder2;
    static JScrollPane scrollPane2;
    static JTextArea textOrder3;
    static JScrollPane scrollPane3;
    static JSlider slider1;
    static long beforeUsedMem;
    static PO checkEdge;
    static PO reachable;
    static int edgeCount;
    public static final int INNER_WIDTH = 50;
    public static final int OUTER_WIDTH = 40;
    
    static {
        PartialOrder.rlist = null;
        PartialOrder.FR = null;
        PartialOrder.NFR = null;
        PartialOrder.E_FN = null;
        PartialOrder.E_NN = null;
        PartialOrder.E_FF = null;
        PartialOrder.bcHead = null;
        PartialOrder.mcHead = null;
        PartialOrder.root = null;
        PartialOrder.proot = null;
        PartialOrder.LNFR1 = null;
        PartialOrder.LNFR2 = null;
        PartialOrder.droot = null;
        PartialOrder.countNFR = 0;
        PartialOrder.countFR = 0;
        PartialOrder.choice = 0;
        PartialOrder.w1 = 0.0;
        PartialOrder.w2 = 0.0;
        PartialOrder.frame1 = new JFrame("Set NFR Priority & Select Parameter");
        PartialOrder.NFRlabels = new JLabel[100];
        PartialOrder.NFRPriority = new JTextField[100];
        PartialOrder.label1 = new JLabel();
        PartialOrder.label2 = new JLabel();
        PartialOrder.label3 = new JLabel();
        PartialOrder.label4 = new JLabel();
        PartialOrder.label5 = new JLabel();
        PartialOrder.label6 = new JLabel();
        PartialOrder.label7 = new JLabel();
        PartialOrder.label8 = new JLabel();
        PartialOrder.label9 = new JLabel();
        savePriority = new JButton("SAVE");
        conflict = new JRadioButton("Conflict");
        priority = new JRadioButton("NFR Priority");
        both = new JRadioButton("Product");
        both2 = new JRadioButton("Weighted sum");
        nc = new JRadioButton("Without conflict");
        submit = new JButton("SUBMIT");
        generate = new JButton("GENERATE PARTIAL ORDER");
        viewgraph = new JButton("View PO graph");
        PartialOrder.textOrder1 = new JTextArea(400, 400);
        PartialOrder.scrollPane1 = new JScrollPane(PartialOrder.textOrder1);
        PartialOrder.textOrder2 = new JTextArea(100, 600);
        PartialOrder.scrollPane2 = new JScrollPane(PartialOrder.textOrder2);
        PartialOrder.textOrder3 = new JTextArea(100, 600);
        PartialOrder.scrollPane3 = new JScrollPane(PartialOrder.textOrder3);
        PartialOrder.slider1 = new JSlider(0, 0, 10, 0);
        PartialOrder.beforeUsedMem = 0L;
        PartialOrder.checkEdge = null;
        PartialOrder.reachable = null;
        PartialOrder.edgeCount = 0;
    }
    
    public static void main(final String[] args) {
        PartialOrder.beforeUsedMem = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        PartialOrder.choice = 0;
        createFR_NFR_List();
        create_other_Edges();
        display_List();
        create_frame();
    }
    
    public PartialOrder() {
        super("Draw Circles In JFrame");
        this.setDefaultCloseOperation(3);
        this.setSize(400, 400);
        this.setVisible(true);
    }
    
    public static void createFR_NFR_List() {
        FileReader f1 = null;
        PartialOrder.FR = null;
        PartialOrder.NFR = null;
        String Fname = "";
        String Nname = "";
        try {
            f1 = new FileReader("DataSet1.txt");
            final int flagexit = 0;
            int i;
            while ((i = f1.read()) != -1) {
                Fname = "";
                char c = (char)i;
                Edge1 q = null;
                Fname = Fname.concat(Character.toString(c));
                while ((i = f1.read()) != 32 && i != 10 && i != 13) {
                    c = (char)i;
                    Fname = Fname.concat(Character.toString(c));
                }
                final Node temp = new Node();
                temp.id = Fname;
                temp.next = null;
                if (PartialOrder.FR == null) {
                    PartialOrder.FR = temp;
                    ++PartialOrder.countFR;
                }
                else {
                    Node p;
                    for (p = PartialOrder.FR; p.next != null; p = p.next) {}
                    ++PartialOrder.countFR;
                    p.next = temp;
                }
                int flag = 0;
                Nname = "";
                int flag_locate = 0;
                while (flag == 0) {
                    i = f1.read();
                    if (i == -1) {
                        break;
                    }
                    if (i == 44 || i == 32) {
                        int duplicate = 0;
                        final Node temp2 = new Node();
                        temp2.id = Nname;
                        temp2.next = null;
                        final Edge1 temp_edge = new Edge1();
                        temp_edge.id1 = Fname;
                        temp_edge.id2 = Nname;
                        temp_edge.next = null;
                        if (PartialOrder.E_FN == null) {
                            PartialOrder.E_FN = temp_edge;
                            q = PartialOrder.E_FN;
                            flag_locate = 1;
                        }
                        else {
                            Edge1 p2;
                            for (p2 = PartialOrder.E_FN; p2.next != null; p2 = p2.next) {}
                            p2.next = temp_edge;
                            if (flag_locate == 0) {
                                flag_locate = 1;
                                q = p2.next;
                            }
                        }
                        if (PartialOrder.NFR == null) {
                            ++PartialOrder.countNFR;
                            PartialOrder.NFR = temp2;
                        }
                        else {
                            Node r;
                            Node p3 = r = PartialOrder.NFR;
                            while (p3 != null) {
                                r = p3;
                                p3 = p3.next;
                                if (r.id.compareTo(Nname) == 0) {
                                    duplicate = 1;
                                }
                            }
                            if (duplicate == 0) {
                                ++PartialOrder.countNFR;
                                r.next = temp2;
                            }
                            else {
                                duplicate = 0;
                            }
                        }
                        if (i == 32) {
                            flag = 1;
                        }
                        Nname = "";
                    }
                    else {
                        c = (char)i;
                        Nname = Nname.concat(Character.toString(c));
                    }
                }
                String value = "";
                while ((i = f1.read()) != 10 && i != -1 && i != 13) {
                    c = (char)i;
                    value = value.concat(Character.toString(c));
                    int flag_check = 0;
                    while (flag_check == 0) {
                        i = f1.read();
                        if (i == 44 || i == 32) {
                            flag_check = 1;
                        }
                        else {
                            c = (char)i;
                            value = value.concat(Character.toString(c));
                        }
                    }
                    final int values = Integer.valueOf(value);
                    q.value = values;
                    final Edge1 r2 = q.next;
                    if (r2 != null) {
                        q = q.next;
                    }
                    value = "";
                }
                i = f1.read();
            }
            f1.close();
        }
        catch (IOException e) {
            System.out.println("unreachable 2");
        }
    }
    
    public static void create_other_Edges() {
        FileReader f1 = null;
        String name1 = "";
        String name2 = "";
        String value = "";
        try {
            f1 = new FileReader("DataSet2.txt");
            int i;
            while ((i = f1.read()) != -1) {
                name1 = "";
                name2 = "";
                value = "";
                char c = (char)i;
                name1 = name1.concat(Character.toString(c));
                while ((i = f1.read()) != 44) {
                    c = (char)i;
                    name1 = name1.concat(Character.toString(c));
                }
                while ((i = f1.read()) != 44) {
                    c = (char)i;
                    name2 = name2.concat(Character.toString(c));
                }
                while ((i = f1.read()) != 10 && i != 13) {
                    c = (char)i;
                    value = value.concat(Character.toString(c));
                }
                i = f1.read();
                final int val = Integer.valueOf(value);
                final Edge1 temp = new Edge1();
                temp.id1 = name1;
                temp.id2 = name2;
                temp.value = val;
                temp.next = null;
                if (PartialOrder.E_NN == null) {
                    PartialOrder.E_NN = temp;
                }
                else {
                    Edge1 p;
                    for (p = PartialOrder.E_NN; p.next != null; p = p.next) {}
                    p.next = temp;
                }
            }
            f1.close();
        }
        catch (IOException e) {
            System.out.println("unreachable 2");
        }
        try {
            f1 = new FileReader("DataSet3.txt");
            int i;
            while ((i = f1.read()) != -1) {
                name1 = "";
                name2 = "";
                char c = (char)i;
                name1 = name1.concat(Character.toString(c));
                while ((i = f1.read()) != 44) {
                    c = (char)i;
                    name1 = name1.concat(Character.toString(c));
                }
                while ((i = f1.read()) != 10) {
                    if (i != 13) {
                        c = (char)i;
                        name2 = name2.concat(Character.toString(c));
                    }
                }
                final Edge2 temp2 = new Edge2();
                temp2.id1 = name1;
                temp2.id2 = name2;
                temp2.next = null;
                if (PartialOrder.E_FF == null) {
                    PartialOrder.E_FF = temp2;
                }
                else {
                    Edge2 p2;
                    for (p2 = PartialOrder.E_FF; p2.next != null; p2 = p2.next) {}
                    p2.next = temp2;
                }
            }
            f1.close();
        }
        catch (IOException e) {
            System.out.println("unreachable 2");
        }
    }
    
    public static void display_List() {
        for (Node p = PartialOrder.FR; p != null; p = p.next) {}
        for (Node p = PartialOrder.NFR; p != null; p = p.next) {}
        for (Edge1 q = PartialOrder.E_FN; q != null; q = q.next) {
            System.out.println("FR:" + q.id1);
            System.out.println("NFR:" + q.id2);
            System.out.println("Dependency value:" + q.value);
        }
        for (Edge1 q = PartialOrder.E_NN; q != null; q = q.next) {
            System.out.println("NFR:" + q.id1);
            System.out.println("NFR:" + q.id2);
            System.out.println("Conflict value:" + q.value);
        }
        Edge2 r = PartialOrder.E_FF;
        System.out.println("The temporal edges are: ");
        while (r != null) {
            System.out.println("FR:" + r.id1);
            System.out.println("FR:" + r.id2);
            r = r.next;
        }
    }
    
    public static void create_BasicClusters() {
        Node nfr = PartialOrder.NFR;
        PartialOrder.bcHead = null;
        while (nfr != null) {
            final BC temp = new BC();
            temp.Nid = nfr.id;
            Edge1 fn = PartialOrder.E_FN;
            FRDep flist = null;
            while (fn != null) {
                if (fn.id2.compareTo(nfr.id) == 0) {
                    final FRDep fnode = new FRDep();
                    fnode.id = fn.id1;
                    fnode.val = fn.value;
                    fnode.next = null;
                    if (flist == null) {
                        flist = fnode;
                    }
                    else {
                        FRDep p;
                        for (p = flist; p.next != null; p = p.next) {}
                        p.next = fnode;
                    }
                }
                fn = fn.next;
            }
            if (flist != null) {
                temp.begin = flist;
            }
            temp.next = null;
            if (PartialOrder.bcHead == null) {
                PartialOrder.bcHead = temp;
            }
            else {
                BC q;
                for (q = PartialOrder.bcHead; q.next != null; q = q.next) {}
                q.next = temp;
            }
            nfr = nfr.next;
        }
    }
    
    public static void display_BasicClusters() {
        BC p = PartialOrder.bcHead;
        System.out.println();
        System.out.println("The basic clusters are:");
        System.out.println();
        while (p != null) {
            System.out.println("NFR: " + p.Nid);
            for (FRDep q = p.begin; q != null; q = q.next) {
                System.out.println("FR: " + q.id);
                System.out.println("Dependency Edge Weight: " + q.val);
            }
            System.out.println();
            p = p.next;
        }
    }
    
    public static void create_MacroClusters() {
        Edge1 Nconflict = PartialOrder.E_NN;
        PartialOrder.mcHead = null;
        while (Nconflict != null) {
            BC p = PartialOrder.bcHead;
            final MC temp = new MC();
            temp.next = null;
            temp.Blist = null;
            temp.CEdge = 1;
            while (p != null) {
                if (p.Nid.compareTo(Nconflict.id1) == 0 || p.Nid.compareTo(Nconflict.id2) == 0) {
                    final BC newBC = new BC();
                    newBC.Nid = p.Nid;
                    newBC.begin = p.begin;
                    newBC.next = null;
                    if (temp.Blist == null) {
                        temp.Blist = newBC;
                    }
                    else {
                        BC q;
                        for (q = temp.Blist; q.next != null; q = q.next) {}
                        q.next = newBC;
                    }
                }
                p = p.next;
            }
            if (PartialOrder.mcHead == null) {
                PartialOrder.mcHead = temp;
            }
            else {
                MC r;
                for (r = PartialOrder.mcHead; r.next != null; r = r.next) {}
                r.next = temp;
            }
            Nconflict = Nconflict.next;
        }
    }
    
    public static void display_MacroClusters() {
        MC p = PartialOrder.mcHead;
        System.out.println();
        System.out.println("The macro clusters are:");
        System.out.println();
        while (p != null) {
            System.out.println("A macro cluster");
            for (BC q = p.Blist; q != null; q = q.next) {
                System.out.println("NFR: " + q.Nid);
                for (FRDep r = q.begin; r != null; r = r.next) {
                    System.out.println("FR: " + r.id);
                    System.out.println("Dependency Edge Weight: " + r.val);
                }
                System.out.println();
            }
            p = p.next;
        }
    }
    
    public static void create_requirementSet() {
        PartialOrder.root = null;
        for (Node p = PartialOrder.FR; p.next != null; p = p.next) {
            for (Node q = p.next; q != null; q = q.next) {
                final Rpair temp = new Rpair();
                temp.id1 = p.id;
                temp.id2 = q.id;
                temp.done = 0;
                temp.next = null;
                if (PartialOrder.root == null) {
                    PartialOrder.root = temp;
                }
                else {
                    Rpair s;
                    for (s = PartialOrder.root; s.next != null; s = s.next) {}
                    s.next = temp;
                }
            }
        }
    }
    
    public static void display_requirementSet() {
        Rpair p = PartialOrder.root;
        int count = 0;
        System.out.println("The requirements pair are: ");
        while (p != null) {
            System.out.println(String.valueOf(p.id1) + " " + p.id2);
            p = p.next;
            ++count;
        }
        System.out.println("The count is : " + count);
    }
    
    public static void generate_PartialOrderNew() {
        PartialOrder.proot = null;
        for (Rpair point = PartialOrder.root; point != null; point = point.next) {
            Edge2 p = PartialOrder.E_FF;
            int tflag = 0;
            while (p != null) {
                if ((p.id1.compareTo(point.id1) == 0 && p.id2.compareTo(point.id2) == 0) || (p.id1.compareTo(point.id2) == 0 && p.id2.compareTo(point.id1) == 0)) {
                    tflag = 1;
                    break;
                }
                p = p.next;
            }
            if (tflag == 1) {
                System.out.println("Temporal Edge found for : " + point.id1 + " " + point.id2);
                point.done = 1;
                final PO temp = new PO();
                temp.id1 = p.id1;
                temp.id2 = p.id2;
                temp.next = null;
                if (PartialOrder.proot == null) {
                    PartialOrder.proot = temp;
                }
                else {
                    PO r;
                    for (r = PartialOrder.proot; r.next != null; r = r.next) {}
                    r.next = temp;
                }
            }
        }
        for (Rpair point = PartialOrder.root; point != null; point = point.next) {
            String fr1 = point.id1;
            String fr2 = point.id2;
            System.out.println("Checking for " + fr1 + " " + fr2);
            if (point.done == 0) {
                fr1 = point.id1;
                fr2 = point.id2;
                System.out.println("Checking for " + fr1 + " " + fr2);
                int flagmc1 = 0;
                int flagmc2 = 0;
                int flagmc3 = 0;
                for (MC p2 = PartialOrder.mcHead; p2 != null; p2 = p2.next) {
                    flagmc1 = 0;
                    flagmc2 = 0;
                    for (BC q = p2.Blist; q != null; q = q.next) {
                        for (FRDep r2 = q.begin; r2 != null; r2 = r2.next) {
                            if (r2.id.compareTo(fr1) == 0) {
                                flagmc1 = 1;
                            }
                            if (r2.id.compareTo(fr2) == 0) {
                                flagmc2 = 1;
                            }
                        }
                    }
                    if (flagmc1 == 1 && flagmc2 == 1) {
                        flagmc3 = 1;
                        break;
                    }
                }
                if (flagmc3 == 1) {
                    point.done = 1;
                    System.out.println("Belong to same macro cluster " + fr1 + " " + fr2);
                    if (PartialOrder.choice == 1) {
                        case1(fr1, fr2);
                    }
                    else if (PartialOrder.choice == 2) {
                        case2(fr1, fr2);
                    }
                    else if (PartialOrder.choice == 3) {
                        case3(fr1, fr2);
                    }
                    else if (PartialOrder.choice == 4) {
                        case4(fr1, fr2);
                    }
                }
                else {
                    int rflag1 = 0;
                    int rflag2 = 0;
                    PartialOrder.LNFR1 = null;
                    PartialOrder.LNFR2 = null;
                    for (BC bcluster = PartialOrder.bcHead; bcluster != null; bcluster = bcluster.next) {
                        FRDep s = bcluster.begin;
                        while (s != null) {
                            if (s.id.compareTo(point.id1) == 0) {
                                rflag1 = 1;
                                final Node temp2 = new Node();
                                temp2.id = bcluster.Nid;
                                temp2.next = null;
                                if (PartialOrder.LNFR1 == null) {
                                    PartialOrder.LNFR1 = temp2;
                                    break;
                                }
                                Node q2;
                                for (q2 = PartialOrder.LNFR1; q2.next != null; q2 = q2.next) {}
                                q2.next = temp2;
                                break;
                            }
                            else {
                                s = s.next;
                            }
                        }
                    }
                    for (BC bcluster = PartialOrder.bcHead; bcluster != null; bcluster = bcluster.next) {
                        FRDep s = bcluster.begin;
                        while (s != null) {
                            if (s.id.compareTo(point.id2) == 0) {
                                rflag2 = 1;
                                final Node temp2 = new Node();
                                temp2.id = bcluster.Nid;
                                temp2.next = null;
                                if (PartialOrder.LNFR2 == null) {
                                    PartialOrder.LNFR2 = temp2;
                                    break;
                                }
                                Node q2;
                                for (q2 = PartialOrder.LNFR2; q2.next != null; q2 = q2.next) {}
                                q2.next = temp2;
                                break;
                            }
                            else {
                                s = s.next;
                            }
                        }
                    }
                    int count = 0;
                    int noteq = 0;
                    if (rflag1 == 1 && rflag2 == 1) {
                        Node l1 = PartialOrder.LNFR1;
                        int check = 0;
                        while (l1 != null) {
                            Node l2 = PartialOrder.LNFR2;
                            check = 0;
                            while (l2 != null) {
                                if (l1.id.compareTo(l2.id) == 0) {
                                    check = 1;
                                    ++count;
                                    break;
                                }
                                l2 = l2.next;
                            }
                            l1 = l1.next;
                            if (check == 0) {
                                noteq = 1;
                            }
                        }
                        l1 = PartialOrder.LNFR2;
                        check = 0;
                        while (l1 != null) {
                            Node l2 = PartialOrder.LNFR1;
                            check = 0;
                            while (l2 != null) {
                                if (l1.id.compareTo(l2.id) == 0) {
                                    check = 1;
                                    ++count;
                                    break;
                                }
                                l2 = l2.next;
                            }
                            l1 = l1.next;
                            if (check == 0) {
                                noteq = 1;
                            }
                        }
                    }
                    if (count > 0) {
                        point.done = 1;
                        caseB(fr1, fr2);
                    }
                }
            }
            for (PO j = PartialOrder.proot; j != null; j = j.next) {
                if (j.next == null) {
                    System.out.println("added edge is : " + j.id1 + "->" + j.id2);
                    break;
                }
            }
            final int f = check_Loop();
            if (f == 1) {
                System.out.println("Loop is formed");
                PO p3 = PartialOrder.proot;
                PO q3 = p3.next;
                if (q3 != null) {
                    while (q3.next != null) {
                        p3 = p3.next;
                        q3 = p3.next;
                    }
                    p3.next = null;
                }
            }
            for (PO v = PartialOrder.proot; v != null; v = v.next) {
                v.visited = 0;
            }
            for (PO rt = PartialOrder.proot; rt != null; rt = rt.next) {
                final String p4 = rt.id2;
                final String g = rt.id1;
                for (PO ct = PartialOrder.proot; ct != null; ct = ct.next) {
                    if (ct.id1.compareTo(p4) == 0) {
                        Rpair k = PartialOrder.root;
                        final String t1 = p4;
                        final String t2 = ct.id2;
                        while (k != null) {
                            if ((k.id1.compareTo(g) != 0 || k.id2.compareTo(t2) != 0) && k.id1.compareTo(t2) == 0) {
                                k.id2.compareTo(g);
                            }
                            k = k.next;
                        }
                    }
                }
            }
        }
    }
    
    public static void caseB(final String fr1, final String fr2) {
        Node t = PartialOrder.NFR;
        String maxNFR = null;
        int priority = 0;
        while (t != null) {
            BC b = PartialOrder.bcHead;
            while (b != null) {
                if (b.Nid.compareTo(t.id) == 0) {
                    int flag1 = 0;
                    int flag2 = 0;
                    for (FRDep k = b.begin; k != null; k = k.next) {
                        if (k.id.compareTo(fr1) == 0) {
                            flag1 = 1;
                        }
                        if (k.id.compareTo(fr2) == 0) {
                            flag2 = 1;
                        }
                    }
                    if (flag1 == 1 && flag2 == 1 && priority < t.priority) {
                        priority = t.priority;
                        maxNFR = t.id;
                        break;
                    }
                    break;
                }
                else {
                    b = b.next;
                }
            }
            t = t.next;
        }
        System.out.println("Max NFR is: " + maxNFR);
        BC b = PartialOrder.bcHead;
        int val1 = 0;
        int val2 = 0;
        while (b != null) {
            if (b.Nid.compareTo(maxNFR) == 0) {
                final int flag3 = 0;
                final int flag4 = 0;
                for (FRDep i = b.begin; i != null; i = i.next) {
                    if (i.id.compareTo(fr1) == 0) {
                        val1 = i.val;
                    }
                    if (i.id.compareTo(fr2) == 0) {
                        val2 = i.val;
                    }
                }
            }
            b = b.next;
        }
        final PO temp = new PO();
        if (val1 >= val2) {
            temp.id1 = fr1;
            temp.id2 = fr2;
        }
        else if (val1 < val2) {
            temp.id1 = fr2;
            temp.id2 = fr1;
        }
        if (PartialOrder.proot == null) {
            PartialOrder.proot = temp;
        }
        else {
            PO r;
            for (r = PartialOrder.proot; r.next != null; r = r.next) {}
            r.next = temp;
        }
    }
    
    public static void case1(final String fr1, final String fr2) {
        int max = 0;
        String nfr1 = null;
        String nfr2 = null;
        for (MC p = PartialOrder.mcHead; p != null; p = p.next) {
            int flagmc1 = 0;
            int flagmc2 = 0;
            String N1 = null;
            String N2 = null;
            for (BC q = p.Blist; q != null; q = q.next) {
                for (FRDep r = q.begin; r != null; r = r.next) {
                    if (r.id.compareTo(fr1) == 0) {
                        flagmc1 = 1;
                    }
                    if (r.id.compareTo(fr2) == 0) {
                        flagmc2 = 1;
                    }
                }
            }
            if (flagmc1 == 1 && flagmc2 == 1) {
                BC q = p.Blist;
                N1 = q.Nid;
                q = q.next;
                N2 = q.Nid;
                for (Edge1 conflict = PartialOrder.E_NN; conflict != null; conflict = conflict.next) {
                    if (((N1.compareTo(conflict.id1) == 0 && N2.compareTo(conflict.id2) == 0) || (N1.compareTo(conflict.id2) == 0 && N2.compareTo(conflict.id1) == 0)) && max < conflict.value) {
                        max = conflict.value;
                        nfr1 = N1;
                        nfr2 = N2;
                    }
                }
            }
        }
        System.out.println("The NFRs are " + nfr1 + " " + nfr2);
        String maxNFR = null;
        String minNFR = null;
        int val1 = 0;
        int val2 = 0;
        for (Node t = PartialOrder.NFR; t != null; t = t.next) {
            if (t.id.compareTo(nfr1) == 0) {
                val1 = t.priority;
            }
            else if (t.id.compareTo(nfr2) == 0) {
                val2 = t.priority;
            }
        }
        if (val1 > val2) {
            maxNFR = nfr1;
            minNFR = nfr2;
        }
        else if (val1 < val2) {
            maxNFR = nfr2;
            minNFR = nfr1;
        }
        System.out.println("Max NFR is: " + maxNFR);
        BC bclist = PartialOrder.bcHead;
        int flag1 = 0;
        int flag2 = 0;
        int v1 = 0;
        int v2 = 0;
        while (bclist != null) {
            flag1 = 0;
            flag2 = 0;
            if (maxNFR.compareTo(bclist.Nid) == 0) {
                for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                    if (flist.id.compareTo(fr1) == 0) {
                        flag1 = 1;
                        v1 = flist.val;
                    }
                    else if (flist.id.compareTo(fr2) == 0) {
                        flag2 = 1;
                        v2 = flist.val;
                    }
                }
                break;
            }
            bclist = bclist.next;
        }
        final PO temp = new PO();
        if (flag1 == 1 && flag2 == 1) {
            if (v1 >= v2) {
                temp.id1 = fr1;
                temp.id2 = fr2;
            }
            else {
                temp.id1 = fr2;
                temp.id2 = fr1;
            }
        }
        else if (flag1 == 1) {
            temp.id1 = fr1;
            temp.id2 = fr2;
        }
        else if (flag2 == 1) {
            temp.id1 = fr2;
            temp.id2 = fr1;
        }
        else {
            System.out.println("Executing else with Min NFR is: " + minNFR);
            bclist = PartialOrder.bcHead;
            v1 = 0;
            v2 = 0;
            while (bclist != null) {
                flag1 = 0;
                flag2 = 0;
                if (minNFR.compareTo(bclist.Nid) == 0) {
                    for (FRDep flist2 = bclist.begin; flist2 != null; flist2 = flist2.next) {
                        if (flist2.id.compareTo(fr1) == 0) {
                            v1 = flist2.val;
                        }
                        else if (flist2.id.compareTo(fr2) == 0) {
                            v2 = flist2.val;
                        }
                    }
                    break;
                }
                bclist = bclist.next;
            }
            if (v1 >= v2) {
                temp.id1 = fr1;
                temp.id2 = fr2;
            }
            else {
                temp.id1 = fr2;
                temp.id2 = fr1;
            }
        }
        if (PartialOrder.proot == null) {
            PartialOrder.proot = temp;
        }
        else {
            PO r2;
            for (r2 = PartialOrder.proot; r2.next != null; r2 = r2.next) {}
            r2.next = temp;
        }
    }
    
    public static void case2(final String fr1, final String fr2) {
        final int max = 0;
        final String nfr1 = null;
        final String nfr2 = null;
        MC p = PartialOrder.mcHead;
        Node nlist = null;
        while (p != null) {
            int flagmc1 = 0;
            int flagmc2 = 0;
            String N1 = null;
            String N2 = null;
            for (BC q = p.Blist; q != null; q = q.next) {
                for (FRDep r = q.begin; r != null; r = r.next) {
                    if (r.id.compareTo(fr1) == 0) {
                        flagmc1 = 1;
                    }
                    if (r.id.compareTo(fr2) == 0) {
                        flagmc2 = 1;
                    }
                }
            }
            if (flagmc1 == 1 && flagmc2 == 1) {
                BC q = p.Blist;
                N1 = q.Nid;
                q = q.next;
                N2 = q.Nid;
                final Node temp1 = new Node();
                temp1.id = N1;
                final Node temp2 = new Node();
                temp2.id = N2;
                if (nlist == null) {
                    nlist = temp1;
                    temp1.next = temp2;
                }
                else {
                    Node j;
                    for (j = nlist; j.next != null; j = j.next) {}
                    j.next = temp1;
                    temp1.next = temp2;
                }
            }
            p = p.next;
        }
        for (Node f = nlist; f != null; f = f.next) {
            System.out.println(f.id);
        }
        String maxNFR = null;
        final String minNFR = null;
        final int val1 = 0;
        final int val2 = 0;
        Node t = nlist;
        int priority = 0;
        while (t != null) {
            for (Node k = PartialOrder.NFR; k != null; k = k.next) {
                if (k.id.compareTo(t.id) == 0 && priority < k.priority) {
                    priority = k.priority;
                    maxNFR = t.id;
                }
            }
            t = t.next;
        }
        System.out.println("Max NFR is: " + maxNFR);
        BC bclist = PartialOrder.bcHead;
        int flag1 = 0;
        int flag2 = 0;
        int v1 = 0;
        int v2 = 0;
        while (bclist != null) {
            flag1 = 0;
            flag2 = 0;
            if (maxNFR.compareTo(bclist.Nid) == 0) {
                for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                    if (flist.id.compareTo(fr1) == 0) {
                        flag1 = 1;
                        v1 = flist.val;
                    }
                    else if (flist.id.compareTo(fr2) == 0) {
                        flag2 = 1;
                        v2 = flist.val;
                    }
                }
                break;
            }
            bclist = bclist.next;
        }
        final PO temp3 = new PO();
        if (flag1 == 1 && flag2 == 1) {
            if (v1 >= v2) {
                temp3.id1 = fr1;
                temp3.id2 = fr2;
            }
            else {
                temp3.id1 = fr2;
                temp3.id2 = fr1;
            }
        }
        else if (flag1 == 1) {
            temp3.id1 = fr1;
            temp3.id2 = fr2;
        }
        else if (flag2 == 1) {
            temp3.id1 = fr2;
            temp3.id2 = fr1;
        }
        else {
            System.out.println("entering else");
            t = nlist;
            priority = 0;
            int complete = 0;
            String min = "";
            int exists = 1;
            while (exists == 1) {
                exists = 0;
                Node q2;
                t = (q2 = nlist);
                while (t != null) {
                    if (t.id.compareTo(maxNFR) == 0) {
                        if (t == nlist) {
                            nlist = t.next;
                            break;
                        }
                        System.out.println("In else");
                        q2.next = t.next;
                        break;
                    }
                    else {
                        q2 = t;
                        t = t.next;
                    }
                }
                for (Node r2 = nlist; r2 != null; r2 = r2.next) {
                    System.out.println(r2.id);
                    if (r2.id.compareTo(maxNFR) == 0) {
                        exists = 1;
                    }
                }
            }
            System.out.println("Done deletion");
            while (complete == 0) {
                t = nlist;
                priority = 0;
                while (t != null) {
                    Node i = PartialOrder.NFR;
                    System.out.println("compairing " + t.id);
                    while (i != null) {
                        if (i.id.compareTo(t.id) == 0) {
                            System.out.println("Priority is of k:" + i.id + " " + i.priority);
                            if (priority < i.priority) {
                                priority = i.priority;
                                min = i.id;
                            }
                        }
                        i = i.next;
                    }
                    System.out.println("Priority is" + priority);
                    t = t.next;
                }
                System.out.println("NFR selected =" + min);
                flag1 = 0;
                flag2 = 0;
                v1 = 0;
                v2 = 0;
                for (bclist = PartialOrder.bcHead; bclist != null; bclist = bclist.next) {
                    if (min.compareTo(bclist.Nid) == 0) {
                        for (FRDep flist2 = bclist.begin; flist2 != null; flist2 = flist2.next) {
                            if (flist2.id.compareTo(fr1) == 0) {
                                flag1 = 1;
                                v1 = flist2.val;
                            }
                            else if (flist2.id.compareTo(fr2) == 0) {
                                flag2 = 1;
                                v2 = flist2.val;
                            }
                        }
                        break;
                    }
                }
                System.out.println("flag1 and flag2: " + flag1 + " " + flag2);
                if (flag1 == 1 || flag2 == 1) {
                    complete = 1;
                    if (flag1 == 1 && flag2 == 1) {
                        if (v1 >= v2) {
                            temp3.id1 = fr1;
                            temp3.id2 = fr2;
                        }
                        else {
                            temp3.id1 = fr2;
                            temp3.id2 = fr1;
                        }
                    }
                    else if (flag1 == 1) {
                        temp3.id1 = fr1;
                        temp3.id2 = fr2;
                    }
                    else if (flag2 == 1) {
                        temp3.id1 = fr2;
                        temp3.id2 = fr1;
                    }
                }
                exists = 1;
                while (exists == 1) {
                    Node h;
                    Node l = h = nlist;
                    exists = 0;
                    while (l != null) {
                        if (l.id.compareTo(min) == 0) {
                            if (l == nlist) {
                                nlist = l.next;
                                break;
                            }
                            h.next = l.next;
                            break;
                        }
                        else {
                            h = l;
                            l = l.next;
                        }
                    }
                    for (l = nlist; l != null; l = l.next) {
                        if (l.id.compareTo(min) == 0) {
                            exists = 1;
                        }
                    }
                }
            }
        }
        if (PartialOrder.proot == null) {
            PartialOrder.proot = temp3;
        }
        else {
            PO r3;
            for (r3 = PartialOrder.proot; r3.next != null; r3 = r3.next) {}
            r3.next = temp3;
        }
    }
    
    public static void case3(final String fr1, final String fr2) {
        float max = 0.0f;
        String nfr1 = null;
        String nfr2 = null;
        for (MC p = PartialOrder.mcHead; p != null; p = p.next) {
            int flagmc1 = 0;
            int flagmc2 = 0;
            String N1 = null;
            String N2 = null;
            for (BC q = p.Blist; q != null; q = q.next) {
                for (FRDep r = q.begin; r != null; r = r.next) {
                    if (r.id.compareTo(fr1) == 0) {
                        flagmc1 = 1;
                    }
                    if (r.id.compareTo(fr2) == 0) {
                        flagmc2 = 1;
                    }
                }
            }
            if (flagmc1 == 1 && flagmc2 == 1) {
                BC q = p.Blist;
                N1 = q.Nid;
                q = q.next;
                N2 = q.Nid;
                System.out.println("N1 and N2 are" + N1 + " " + N2);
                Edge1 conflict = PartialOrder.E_NN;
                int degree = 0;
                while (conflict != null) {
                    if ((N1.compareTo(conflict.id1) == 0 && N2.compareTo(conflict.id2) == 0) || (N1.compareTo(conflict.id2) == 0 && N2.compareTo(conflict.id1) == 0)) {
                        degree = conflict.value;
                    }
                    conflict = conflict.next;
                }
                System.out.println("The degree is " + degree);
                int p2 = 0;
                int p3 = 0;
                for (Node k = PartialOrder.NFR; k != null; k = k.next) {
                    if (k.id.compareTo(N1) == 0) {
                        p2 = k.priority;
                    }
                    if (k.id.compareTo(N2) == 0) {
                        p3 = k.priority;
                    }
                }
                System.out.println("p1 and p2 are" + p2 + " " + p3);
                final float product = (degree - 40) * ((p2 + p3) / 200.0f);
                System.out.println("Product is" + product);
                if (max < product) {
                    max = product;
                    nfr1 = N1;
                    nfr2 = N2;
                }
            }
        }
        System.out.println("The NFRs are " + nfr1 + " " + nfr2);
        String maxNFR = null;
        String minNFR = null;
        int val1 = 0;
        int val2 = 0;
        for (Node t = PartialOrder.NFR; t != null; t = t.next) {
            if (t.id.compareTo(nfr1) == 0) {
                val1 = t.priority;
            }
            else if (t.id.compareTo(nfr2) == 0) {
                val2 = t.priority;
            }
        }
        if (val1 > val2) {
            maxNFR = nfr1;
            minNFR = nfr2;
        }
        else if (val1 < val2) {
            maxNFR = nfr2;
            minNFR = nfr1;
        }
        BC bclist = PartialOrder.bcHead;
        int flag1 = 0;
        int flag2 = 0;
        int v1 = 0;
        int v2 = 0;
        while (bclist != null) {
            flag1 = 0;
            flag2 = 0;
            if (maxNFR.compareTo(bclist.Nid) == 0) {
                for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                    if (flist.id.compareTo(fr1) == 0) {
                        flag1 = 1;
                        v1 = flist.val;
                    }
                    else if (flist.id.compareTo(fr2) == 0) {
                        flag2 = 1;
                        v2 = flist.val;
                    }
                }
                break;
            }
            bclist = bclist.next;
        }
        final PO temp = new PO();
        if (flag1 == 1 && flag2 == 1) {
            if (v1 >= v2) {
                temp.id1 = fr1;
                temp.id2 = fr2;
            }
            else {
                temp.id1 = fr2;
                temp.id2 = fr1;
            }
        }
        else if (flag1 == 1) {
            temp.id1 = fr1;
            temp.id2 = fr2;
        }
        else if (flag2 == 1) {
            temp.id1 = fr2;
            temp.id2 = fr1;
        }
        else {
            bclist = PartialOrder.bcHead;
            v1 = 0;
            v2 = 0;
            while (bclist != null) {
                flag1 = 0;
                flag2 = 0;
                if (minNFR.compareTo(bclist.Nid) == 0) {
                    for (FRDep flist2 = bclist.begin; flist2 != null; flist2 = flist2.next) {
                        if (flist2.id.compareTo(fr1) == 0) {
                            v1 = flist2.val;
                        }
                        else if (flist2.id.compareTo(fr2) == 0) {
                            v2 = flist2.val;
                        }
                    }
                    break;
                }
                bclist = bclist.next;
            }
            if (v1 >= v2) {
                temp.id1 = fr1;
                temp.id2 = fr2;
            }
            else {
                temp.id1 = fr2;
                temp.id2 = fr1;
            }
        }
        if (PartialOrder.proot == null) {
            PartialOrder.proot = temp;
        }
        else {
            PO r2;
            for (r2 = PartialOrder.proot; r2.next != null; r2 = r2.next) {}
            r2.next = temp;
        }
    }
    
    public static void case4(final String fr1, final String fr2) {
        float max = 0.0f;
        String nfr1 = null;
        String nfr2 = null;
        for (MC p = PartialOrder.mcHead; p != null; p = p.next) {
            int flagmc1 = 0;
            int flagmc2 = 0;
            String N1 = null;
            String N2 = null;
            for (BC q = p.Blist; q != null; q = q.next) {
                for (FRDep r = q.begin; r != null; r = r.next) {
                    if (r.id.compareTo(fr1) == 0) {
                        flagmc1 = 1;
                    }
                    if (r.id.compareTo(fr2) == 0) {
                        flagmc2 = 1;
                    }
                }
            }
            if (flagmc1 == 1 && flagmc2 == 1) {
                BC q = p.Blist;
                N1 = q.Nid;
                q = q.next;
                N2 = q.Nid;
                Edge1 conflict = PartialOrder.E_NN;
                int degree = 0;
                while (conflict != null) {
                    if ((N1.compareTo(conflict.id1) == 0 && N2.compareTo(conflict.id2) == 0) || (N1.compareTo(conflict.id2) == 0 && N2.compareTo(conflict.id1) == 0)) {
                        degree = conflict.value;
                    }
                    conflict = conflict.next;
                }
                int p2 = 0;
                int p3 = 0;
                for (Node k = PartialOrder.NFR; k != null; k = k.next) {
                    if (k.id.compareTo(N1) == 0) {
                        p2 = k.priority;
                    }
                    if (k.id.compareTo(N2) == 0) {
                        p3 = k.priority;
                    }
                }
                final float sum = (float)PartialOrder.w1 * degree + (p2 + p3) * (float)PartialOrder.w2;
                System.out.println("The sum is" + sum);
                if (max < sum) {
                    max = sum;
                    nfr1 = N1;
                    nfr2 = N2;
                }
            }
        }
        System.out.println("The NFRs are " + nfr1 + " " + nfr2);
        String maxNFR = null;
        String minNFR = null;
        int val1 = 0;
        int val2 = 0;
        for (Node t = PartialOrder.NFR; t != null; t = t.next) {
            if (t.id.compareTo(nfr1) == 0) {
                val1 = t.priority;
            }
            else if (t.id.compareTo(nfr2) == 0) {
                val2 = t.priority;
            }
        }
        if (val1 > val2) {
            maxNFR = nfr1;
            minNFR = nfr2;
        }
        else if (val1 < val2) {
            maxNFR = nfr2;
            minNFR = nfr1;
        }
        BC bclist = PartialOrder.bcHead;
        int flag1 = 0;
        int flag2 = 0;
        int v1 = 0;
        int v2 = 0;
        while (bclist != null) {
            flag1 = 0;
            flag2 = 0;
            if (maxNFR.compareTo(bclist.Nid) == 0) {
                for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                    if (flist.id.compareTo(fr1) == 0) {
                        flag1 = 1;
                        v1 = flist.val;
                    }
                    else if (flist.id.compareTo(fr2) == 0) {
                        flag2 = 1;
                        v2 = flist.val;
                    }
                }
                break;
            }
            bclist = bclist.next;
        }
        final PO temp = new PO();
        if (flag1 == 1 && flag2 == 1) {
            if (v1 >= v2) {
                temp.id1 = fr1;
                temp.id2 = fr2;
            }
            else {
                temp.id1 = fr2;
                temp.id2 = fr1;
            }
        }
        else if (flag1 == 1) {
            temp.id1 = fr1;
            temp.id2 = fr2;
        }
        else if (flag2 == 1) {
            temp.id1 = fr2;
            temp.id2 = fr1;
        }
        else {
            bclist = PartialOrder.bcHead;
            v1 = 0;
            v2 = 0;
            while (bclist != null) {
                flag1 = 0;
                flag2 = 0;
                if (minNFR.compareTo(bclist.Nid) == 0) {
                    for (FRDep flist2 = bclist.begin; flist2 != null; flist2 = flist2.next) {
                        if (flist2.id.compareTo(fr1) == 0) {
                            v1 = flist2.val;
                        }
                        else if (flist2.id.compareTo(fr2) == 0) {
                            v2 = flist2.val;
                        }
                    }
                    break;
                }
                bclist = bclist.next;
            }
            if (v1 >= v2) {
                temp.id1 = fr1;
                temp.id2 = fr2;
            }
            else {
                temp.id1 = fr2;
                temp.id2 = fr1;
            }
        }
        if (PartialOrder.proot == null) {
            PartialOrder.proot = temp;
        }
        else {
            PO r2;
            for (r2 = PartialOrder.proot; r2.next != null; r2 = r2.next) {}
            r2.next = temp;
        }
    }
    
    public static int check_Loop() {
        int loop = 0;
        int complete = 0;
        while (complete == 0) {
            sNode root = null;
            for (PO p = PartialOrder.proot; p != null; p = p.next) {
                if (p.visited == 0) {
                    if (root == null) {
                        p.visited = 1;
                        final sNode temp1 = new sNode();
                        temp1.id = p.id1;
                        final sNode temp2 = new sNode();
                        temp2.id = p.id2;
                        temp1.next = temp2;
                        root = temp1;
                        temp1.prev = root;
                        temp2.prev = temp1;
                        temp1.prev = null;
                    }
                    else {
                        final String s1 = p.id1;
                        final String s2 = p.id2;
                        int found = 0;
                        sNode temp3;
                        for (temp3 = root; temp3 != null; temp3 = temp3.next) {
                            if (temp3.id.compareTo(s1) == 0) {
                                found = 1;
                                break;
                            }
                        }
                        final int exists = 0;
                        if (temp3 != null && temp3.next != null && found == 1) {
                            final sNode prev = temp3;
                            sNode k = temp3.next;
                            final String s3 = k.id;
                            int flag1 = 0;
                            int flag2 = 0;
                            sNode hold = null;
                            if (k.next == null) {
                                PO r = PartialOrder.proot;
                                int d = 0;
                                final String c1 = s2;
                                final String c2 = k.id;
                                while (r != null) {
                                    if (r.id1.compareTo(c2) == 0 && r.id2.compareTo(c1) == 0) {
                                        d = 1;
                                        break;
                                    }
                                    r = r.next;
                                }
                                if (d == 1) {
                                    final sNode te = new sNode();
                                    te.id = s2;
                                    k.next = te;
                                    te.prev = k;
                                    p.visited = 1;
                                }
                            }
                            else {
                                int entered = 0;
                                while (k != null) {
                                    final String c3 = s2;
                                    final String c4 = k.id;
                                    final String c5 = k.prev.id;
                                    for (PO r2 = PartialOrder.proot; r2 != null; r2 = r2.next) {
                                        if (r2.id1.compareTo(c5) == 0 && r2.id2.compareTo(c3) == 0) {
                                            flag1 = 1;
                                            break;
                                        }
                                    }
                                    for (PO r2 = PartialOrder.proot; r2 != null; r2 = r2.next) {
                                        if (r2.id1.compareTo(c3) == 0 && r2.id2.compareTo(c4) == 0) {
                                            flag2 = 1;
                                            break;
                                        }
                                    }
                                    if (flag1 == 1 && flag2 == 1) {
                                        hold = k;
                                        break;
                                    }
                                    if (flag1 == 1 && flag2 == 0) {
                                        PO r2 = PartialOrder.proot;
                                        int d2 = 0;
                                        while (r2 != null) {
                                            if (r2.id1.compareTo(c4) == 0 && r2.id2.compareTo(c3) == 0) {
                                                d2 = 1;
                                                break;
                                            }
                                            r2 = r2.next;
                                        }
                                        if (d2 != 1) {
                                            break;
                                        }
                                        if (k.next == null) {
                                            final sNode node = new sNode();
                                            node.id = s2;
                                            k.next = node;
                                            node.prev = k;
                                            p.visited = 1;
                                            entered = 1;
                                            break;
                                        }
                                        k = k.next;
                                    }
                                    else {
                                        k = k.next;
                                    }
                                }
                                if (hold != null && entered == 0) {
                                    final sNode node2 = new sNode();
                                    node2.id = s2;
                                    node2.next = hold;
                                    final sNode t = hold.prev;
                                    t.next = node2;
                                    node2.prev = t;
                                    hold.prev = node2;
                                    p.visited = 1;
                                }
                            }
                        }
                        else if (temp3 != null && temp3.next == null && found == 1) {
                            final sNode node3 = new sNode();
                            node3.id = s2;
                            temp3.next = node3;
                            node3.prev = temp3;
                            p.visited = 1;
                        }
                        if (found == 0) {
                            int check = 0;
                            sNode prev2;
                            sNode k = prev2 = root;
                            int entered2 = 0;
                            while (k != null) {
                                if (k.id.compareTo(s2) == 0) {
                                    check = 1;
                                    break;
                                }
                                prev2 = k;
                                k = k.next;
                            }
                            if (check == 1) {
                                if (k.prev == null) {
                                    final sNode node4 = new sNode();
                                    node4.id = s1;
                                    node4.next = k;
                                    k.prev = node4;
                                    root = node4;
                                    node4.prev = null;
                                    root.prev = null;
                                    p.visited = 1;
                                }
                                else {
                                    final int flag3 = 0;
                                    final sNode pt;
                                    sNode q = pt = k;
                                    sNode hold2 = null;
                                    int d3 = 0;
                                    while (q != null) {
                                        final String c5 = q.id;
                                        final String c6 = s1;
                                        final String c7 = q.prev.id;
                                        int flag4 = 0;
                                        int flag5 = 0;
                                        for (PO t2 = PartialOrder.proot; t2 != null; t2 = t2.next) {
                                            if (t2.id1.compareTo(c6) == 0 && t2.id2.compareTo(c5) == 0) {
                                                flag4 = 1;
                                            }
                                            else if (t2.id1.compareTo(c7) == 0 && t2.id2.compareTo(c6) == 0) {
                                                flag5 = 1;
                                            }
                                        }
                                        System.out.println("flag1=" + flag4 + "flag2=" + flag5);
                                        if (flag4 == 1 && flag5 == 1) {
                                            hold2 = q;
                                            break;
                                        }
                                        if (flag5 == 0 && flag4 == 1) {
                                            d3 = 0;
                                            for (PO t2 = PartialOrder.proot; t2 != null; t2 = t2.next) {
                                                if (t2.id1.compareTo(c6) == 0 && t2.id2.compareTo(c7) == 0) {
                                                    d3 = 1;
                                                    break;
                                                }
                                            }
                                            if (d3 != 1) {
                                                break;
                                            }
                                            final sNode h = q.prev;
                                            if (h.prev == null) {
                                                final sNode te2 = new sNode();
                                                te2.id = s1;
                                                te2.next = h;
                                                h.prev = te2;
                                                root = te2;
                                                te2.prev = null;
                                                entered2 = 1;
                                                p.visited = 1;
                                                break;
                                            }
                                            q = q.prev;
                                        }
                                        else {
                                            q = q.prev;
                                        }
                                    }
                                    if (hold2 != null && entered2 == 0) {
                                        final sNode node5 = new sNode();
                                        node5.id = s1;
                                        final sNode g = hold2.prev;
                                        node5.next = hold2;
                                        g.next = node5;
                                        node5.prev = g;
                                        hold2.prev = node5;
                                        p.visited = 1;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            int count = 0;
            for (PO s4 = PartialOrder.proot; s4 != null; s4 = s4.next) {
                if (s4.visited == 0) {
                    ++count;
                }
            }
            if (count == 0) {
                complete = 1;
            }
            PO j = PartialOrder.proot;
            System.out.println("The sequence is");
            for (sNode t3 = root; t3 != null; t3 = t3.next) {
                System.out.print(String.valueOf(t3.id) + " ");
            }
            while (j != null) {
                final String fr1 = j.id1;
                final String fr2 = j.id2;
                sNode r3 = root;
                int flag6 = 0;
                int flag7 = 0;
                while (r3 != null) {
                    if (r3.id.compareTo(fr1) == 0) {
                        flag6 = 1;
                    }
                    if (r3.id.compareTo(fr2) == 0) {
                        flag7 = 1;
                    }
                    r3 = r3.next;
                }
                if (flag6 == 1 && flag7 == 1) {
                    j.visited = 1;
                }
                j = j.next;
            }
            System.out.println("remaining edges:");
            for (PO g2 = PartialOrder.proot; g2 != null; g2 = g2.next) {
                if (g2.visited == 0) {
                    System.out.println(String.valueOf(g2.id1) + " " + g2.id2);
                }
            }
            System.out.println("after generating sequences");
            sNode k2 = root;
            int e = 0;
            while (k2 != null) {
                e = 0;
                for (sNode f = root; f != null; f = f.next) {
                    if (f.id.compareTo(k2.id) == 0) {
                        ++e;
                    }
                }
                k2 = k2.next;
                if (e > 1) {
                    loop = 1;
                }
            }
        }
        for (PO t4 = PartialOrder.proot; t4 != null; t4 = t4.next) {
            t4.visited = 0;
        }
        if (loop == 1) {
            return 1;
        }
        return 0;
    }
    
    public static void removeCycles() {
        for (PO p = PartialOrder.proot; p != null; p = p.next) {
            final String s1 = p.id2;
            final String s2 = p.id1;
            for (PO q = PartialOrder.proot; q != null; q = q.next) {
                if (q.id1.compareTo(s1) == 0) {
                    final String s3 = q.id2;
                    PO prev;
                    PO k = prev = PartialOrder.proot;
                    while (k != null) {
                        if (k.id1.compareTo(s3) == 0 && k.id2.compareTo(s2) == 0) {
                            System.out.println("First edge: " + s2 + " -> " + s1);
                            System.out.println("Second edge: " + s1 + " -> " + s3);
                            System.out.println("Third edge: " + s3 + " -> " + s2);
                            if (k != PartialOrder.proot) {
                                k = k.next;
                                prev.next = k;
                                break;
                            }
                            break;
                        }
                        else {
                            prev = k;
                            k = k.next;
                        }
                    }
                }
            }
        }
    }
    
    public static int removeCycle2() {
        System.out.println("Cycle in reachable set");
        PO p = PartialOrder.reachable;
        int cycle = 0;
        while (p != null) {
            final String s1 = p.id2;
            final String s2 = p.id1;
            for (PO q = PartialOrder.reachable; q != null; q = q.next) {
                if (q.id1.compareTo(s1) == 0) {
                    final String s3 = q.id2;
                    PO prev;
                    PO k = prev = PartialOrder.reachable;
                    while (k != null) {
                        if (k.id1.compareTo(s3) == 0 && k.id2.compareTo(s2) == 0) {
                            System.out.println("First edge: " + s2 + " -> " + s1);
                            System.out.println("Second edge: " + s1 + " -> " + s3);
                            System.out.println("Third edge: " + s3 + " -> " + s2);
                            PO n;
                            PO m = n = PartialOrder.proot;
                            int flag1 = 0;
                            while (m != null) {
                                if (m.id1.compareTo(s3) == 0 && m.id2.compareTo(s2) == 0) {
                                    if (m == PartialOrder.proot) {
                                        PartialOrder.proot = m.next;
                                    }
                                    else {
                                        n.next = m.next;
                                    }
                                    cycle = 1;
                                    flag1 = 1;
                                    break;
                                }
                                n = m;
                                m = m.next;
                            }
                            if (flag1 != 1) {
                                m = (n = PartialOrder.proot);
                                flag1 = 0;
                                while (m != null) {
                                    if (m.id1.compareTo(s1) == 0 && m.id2.compareTo(s3) == 0) {
                                        if (m == PartialOrder.proot) {
                                            PartialOrder.proot = m.next;
                                        }
                                        else {
                                            n.next = m.next;
                                        }
                                        cycle = 1;
                                        flag1 = 1;
                                        break;
                                    }
                                    n = m;
                                    m = m.next;
                                }
                            }
                            if (flag1 != 1) {
                                m = (n = PartialOrder.proot);
                                flag1 = 0;
                                while (m != null) {
                                    if (m.id1.compareTo(s2) == 0 && m.id2.compareTo(s1) == 0) {
                                        if (m == PartialOrder.proot) {
                                            PartialOrder.proot = m.next;
                                        }
                                        else {
                                            n.next = m.next;
                                        }
                                        cycle = 1;
                                        flag1 = 1;
                                        break;
                                    }
                                    n = m;
                                    m = m.next;
                                }
                                break;
                            }
                            break;
                        }
                        else {
                            prev = k;
                            k = k.next;
                        }
                    }
                }
            }
            p = p.next;
        }
        if (cycle == 1) {
            return 1;
        }
        return 0;
    }
    
    public static void generate_PartialOrder() {
        PartialOrder.proot = null;
        for (Rpair point = PartialOrder.root; point != null; point = point.next) {
            Edge2 p = PartialOrder.E_FF;
            int tflag = 0;
            while (p != null) {
                if ((p.id1.compareTo(point.id1) == 0 && p.id2.compareTo(point.id2) == 0) || (p.id1.compareTo(point.id2) == 0 && p.id2.compareTo(point.id1) == 0)) {
                    tflag = 1;
                    break;
                }
                p = p.next;
            }
            if (tflag == 1) {
                point.done = 1;
                final PO temp = new PO();
                temp.id1 = p.id1;
                temp.id2 = p.id2;
                temp.next = null;
                if (PartialOrder.proot == null) {
                    PartialOrder.proot = temp;
                }
                else {
                    PO r;
                    for (r = PartialOrder.proot; r.next != null; r = r.next) {}
                    r.next = temp;
                }
            }
        }
        for (Rpair point = PartialOrder.root; point != null; point = point.next) {
            PartialOrder.LNFR1 = null;
            PartialOrder.LNFR2 = null;
            for (BC bcluster = PartialOrder.bcHead; bcluster != null; bcluster = bcluster.next) {
                FRDep s = bcluster.begin;
                while (s != null) {
                    if (s.id.compareTo(point.id1) == 0) {
                        final Node temp2 = new Node();
                        temp2.id = bcluster.Nid;
                        temp2.next = null;
                        if (PartialOrder.LNFR1 == null) {
                            PartialOrder.LNFR1 = temp2;
                            break;
                        }
                        Node q;
                        for (q = PartialOrder.LNFR1; q.next != null; q = q.next) {}
                        q.next = temp2;
                        break;
                    }
                    else {
                        s = s.next;
                    }
                }
            }
            for (BC bcluster = PartialOrder.bcHead; bcluster != null; bcluster = bcluster.next) {
                FRDep s = bcluster.begin;
                while (s != null) {
                    if (s.id.compareTo(point.id2) == 0) {
                        final Node temp2 = new Node();
                        temp2.id = bcluster.Nid;
                        temp2.next = null;
                        if (PartialOrder.LNFR2 == null) {
                            PartialOrder.LNFR2 = temp2;
                            break;
                        }
                        Node q;
                        for (q = PartialOrder.LNFR2; q.next != null; q = q.next) {}
                        q.next = temp2;
                        break;
                    }
                    else {
                        s = s.next;
                    }
                }
            }
            int countConflict = 0;
            String fr1 = null;
            String fr2 = null;
            fr1 = point.id1;
            fr2 = point.id2;
            System.out.println("Checking For" + fr1 + " " + fr2);
            Node n1 = PartialOrder.LNFR1;
            int edge = 0;
            while (n1 != null) {
                for (Node n2 = PartialOrder.LNFR2; n2 != null; n2 = n2.next) {
                    for (Edge1 conflict = PartialOrder.E_NN; conflict != null; conflict = conflict.next) {
                        if ((n1.id.compareTo(conflict.id1) == 0 && n2.id.compareTo(conflict.id2) == 0) || (n1.id.compareTo(conflict.id2) == 0 && n2.id.compareTo(conflict.id1) == 0)) {
                            ++countConflict;
                        }
                    }
                }
                n1 = n1.next;
            }
            if (countConflict > 0) {
                edge = 1;
                System.out.println("Atleast one conflict edge exists");
                if (PartialOrder.choice == 2) {
                    Pcase3(fr1, fr2);
                }
                else if (PartialOrder.choice == 1) {
                    if (countConflict > 0) {
                        Pcase6(fr1, fr2);
                    }
                    else {
                        Pcase3(fr1, fr2);
                    }
                }
                else if (PartialOrder.choice == 3) {
                    Pcase8(fr1, fr2);
                }
                else if (PartialOrder.choice == 4) {
                    Pcase11(fr1, fr2);
                }
            }
            if (edge == 1) {
                point.done = 1;
            }
        }
        for (Rpair point = PartialOrder.root; point != null; point = point.next) {
            String fr1 = null;
            String fr2 = null;
            fr1 = point.id1;
            fr2 = point.id2;
            System.out.println("done with " + fr1 + " " + fr2);
            int edge2 = 0;
            if (point.done == 0) {
                edge2 = 0;
                int rflag1 = 0;
                int rflag2 = 0;
                PartialOrder.LNFR1 = null;
                PartialOrder.LNFR2 = null;
                for (BC bcluster2 = PartialOrder.bcHead; bcluster2 != null; bcluster2 = bcluster2.next) {
                    FRDep s2 = bcluster2.begin;
                    while (s2 != null) {
                        if (s2.id.compareTo(point.id1) == 0) {
                            rflag1 = 1;
                            final Node temp3 = new Node();
                            temp3.id = bcluster2.Nid;
                            temp3.next = null;
                            if (PartialOrder.LNFR1 == null) {
                                PartialOrder.LNFR1 = temp3;
                                break;
                            }
                            Node q2;
                            for (q2 = PartialOrder.LNFR1; q2.next != null; q2 = q2.next) {}
                            q2.next = temp3;
                            break;
                        }
                        else {
                            s2 = s2.next;
                        }
                    }
                }
                for (BC bcluster2 = PartialOrder.bcHead; bcluster2 != null; bcluster2 = bcluster2.next) {
                    FRDep s2 = bcluster2.begin;
                    while (s2 != null) {
                        if (s2.id.compareTo(point.id2) == 0) {
                            rflag2 = 1;
                            final Node temp3 = new Node();
                            temp3.id = bcluster2.Nid;
                            temp3.next = null;
                            if (PartialOrder.LNFR2 == null) {
                                PartialOrder.LNFR2 = temp3;
                                break;
                            }
                            Node q2;
                            for (q2 = PartialOrder.LNFR2; q2.next != null; q2 = q2.next) {}
                            q2.next = temp3;
                            break;
                        }
                        else {
                            s2 = s2.next;
                        }
                    }
                }
                int count = 0;
                int noteq = 0;
                if (rflag1 == 1 && rflag2 == 1) {
                    Node l1 = PartialOrder.LNFR1;
                    int check = 0;
                    while (l1 != null) {
                        Node l2 = PartialOrder.LNFR2;
                        check = 0;
                        while (l2 != null) {
                            if (l1.id.compareTo(l2.id) == 0) {
                                check = 1;
                                ++count;
                                break;
                            }
                            l2 = l2.next;
                        }
                        l1 = l1.next;
                        if (check == 0) {
                            noteq = 1;
                        }
                    }
                    l1 = PartialOrder.LNFR2;
                    check = 0;
                    while (l1 != null) {
                        Node l2 = PartialOrder.LNFR1;
                        check = 0;
                        while (l2 != null) {
                            if (l1.id.compareTo(l2.id) == 0) {
                                check = 1;
                                ++count;
                                break;
                            }
                            l2 = l2.next;
                        }
                        l1 = l1.next;
                        if (check == 0) {
                            noteq = 1;
                        }
                    }
                    if (noteq == 0) {
                        edge2 = 1;
                        if (PartialOrder.choice == 2) {
                            Pcase1(fr1, fr2);
                        }
                        else if (PartialOrder.choice == 1) {
                            Pcase2(fr1, fr2);
                        }
                        else if (PartialOrder.choice == 3) {
                            Pcase7(fr1, fr2);
                        }
                        else if (PartialOrder.choice == 4) {
                            Pcase11(fr1, fr2);
                        }
                    }
                    else if (count >= 1) {
                        System.out.println("Atleast One sharing NFR for " + fr1 + " " + fr2);
                        edge2 = 1;
                        if (PartialOrder.choice == 2) {
                            Pcase5(fr1, fr2);
                        }
                        else if (PartialOrder.choice == 1) {
                            Pcase6(fr1, fr2);
                        }
                        else if (PartialOrder.choice == 3) {
                            Pcase10(fr1, fr2);
                        }
                        else if (PartialOrder.choice == 4) {
                            Pcase11(fr1, fr2);
                        }
                    }
                }
            }
            point.done = 1;
        }
    }
    
    public static void Pcase1(final String fr1, final String fr2) {
        System.out.println("Called Pcase1");
        int max = 0;
        String nfr = null;
        for (Node t = PartialOrder.LNFR1; t != null; t = t.next) {
            for (Node q = PartialOrder.NFR; q != null; q = q.next) {
                if (q.id.compareTo(t.id) == 0 && max <= q.priority) {
                    max = q.priority;
                    nfr = q.id;
                }
            }
        }
        BC bhead = PartialOrder.bcHead;
        int val1 = 0;
        int val2 = 0;
        while (bhead != null) {
            if (bhead.Nid.compareTo(nfr) == 0) {
                for (FRDep flist = bhead.begin; flist != null; flist = flist.next) {
                    if (flist.id.compareTo(fr1) == 0) {
                        val1 = flist.val;
                    }
                    else if (flist.id.compareTo(fr2) == 0) {
                        val2 = flist.val;
                    }
                }
            }
            bhead = bhead.next;
        }
        final PO temp = new PO();
        if (val1 >= val2) {
            temp.id1 = fr1;
            temp.id2 = fr2;
        }
        else {
            temp.id1 = fr2;
            temp.id2 = fr1;
        }
        if (PartialOrder.proot == null) {
            PartialOrder.proot = temp;
        }
        else {
            PO r;
            for (r = PartialOrder.proot; r.next != null; r = r.next) {}
            r.next = temp;
        }
    }
    
    public static void Pcase2(final String fr1, final String fr2) {
        System.out.println("Called Pcase2");
        Node t1 = PartialOrder.LNFR1;
        int max = 0;
        String nfr1 = null;
        String nfr2 = null;
        while (t1 != null) {
            for (Node t2 = t1.next; t2 != null; t2 = t2.next) {
                for (Edge1 conflict = PartialOrder.E_NN; conflict != null; conflict = conflict.next) {
                    if (((t1.id.compareTo(conflict.id1) == 0 && t2.id.compareTo(conflict.id2) == 0) || (t1.id.compareTo(conflict.id2) == 0 && t2.id.compareTo(conflict.id1) == 0)) && max <= conflict.value) {
                        max = conflict.value;
                        nfr1 = conflict.id1;
                        nfr2 = conflict.id2;
                    }
                }
            }
            t1 = t1.next;
        }
        int vn1 = 0;
        int vn2 = 0;
        if (max > 0) {
            for (Node q = PartialOrder.NFR; q != null; q = q.next) {
                if (q.id.compareTo(nfr1) == 0) {
                    vn1 = q.priority;
                }
                else if (q.id.compareTo(nfr2) == 0) {
                    vn2 = q.priority;
                }
            }
            String search = null;
            if (vn1 >= vn2) {
                search = nfr1;
            }
            else {
                search = nfr2;
            }
            BC bhead = PartialOrder.bcHead;
            int val1 = 0;
            int val2 = 0;
            while (bhead != null) {
                if (bhead.Nid.compareTo(search) == 0) {
                    for (FRDep flist = bhead.begin; flist != null; flist = flist.next) {
                        if (flist.id.compareTo(fr1) == 0) {
                            val1 = flist.val;
                        }
                        else if (flist.id.compareTo(fr2) == 0) {
                            val2 = flist.val;
                        }
                    }
                    break;
                }
                bhead = bhead.next;
            }
            System.out.println("The dependency values are : " + val1 + "," + val2 + "respectively");
            final PO temp = new PO();
            if (val1 >= val2) {
                temp.id1 = fr1;
                temp.id2 = fr2;
            }
            else {
                temp.id1 = fr2;
                temp.id2 = fr1;
            }
            if (PartialOrder.proot == null) {
                PartialOrder.proot = temp;
            }
            else {
                PO r;
                for (r = PartialOrder.proot; r.next != null; r = r.next) {}
                r.next = temp;
            }
        }
        else {
            Pcase1(fr1, fr2);
        }
        System.out.println("End Of Function");
    }
    
    public static void Pcase3(final String fr1, final String fr2) {
        int max = 0;
        String nfr = null;
        for (Node t = PartialOrder.LNFR1; t != null; t = t.next) {
            for (Node q = PartialOrder.NFR; q != null; q = q.next) {
                if (q.id.compareTo(t.id) == 0 && max <= q.priority) {
                    max = q.priority;
                    nfr = q.id;
                }
            }
        }
        Node t = PartialOrder.LNFR2;
        int change = 0;
        while (t != null) {
            for (Node q2 = PartialOrder.NFR; q2 != null; q2 = q2.next) {
                if (q2.id.compareTo(t.id) == 0 && max < q2.priority) {
                    max = q2.priority;
                    nfr = q2.id;
                    change = 1;
                }
            }
            t = t.next;
        }
        final PO temp = new PO();
        if (change == 1) {
            temp.id1 = fr2;
            temp.id2 = fr1;
        }
        else {
            temp.id1 = fr1;
            temp.id2 = fr2;
        }
        if (PartialOrder.proot == null) {
            PartialOrder.proot = temp;
        }
        else {
            PO r;
            for (r = PartialOrder.proot; r.next != null; r = r.next) {}
            r.next = temp;
        }
    }
    
    public static void Pcase4(final String fr1, final String fr2) {
        Node n1 = PartialOrder.LNFR1;
        int max = 0;
        String nfr1 = null;
        String nfr2 = null;
        while (n1 != null) {
            for (Node n2 = PartialOrder.LNFR2; n2 != null; n2 = n2.next) {
                for (Edge1 conflict = PartialOrder.E_NN; conflict != null; conflict = conflict.next) {
                    if (((n1.id.compareTo(conflict.id1) == 0 && n2.id.compareTo(conflict.id2) == 0) || (n1.id.compareTo(conflict.id2) == 0 && n2.id.compareTo(conflict.id1) == 0)) && max < conflict.value) {
                        max = conflict.value;
                        nfr1 = conflict.id1;
                        nfr2 = conflict.id2;
                    }
                }
            }
            n1 = n1.next;
        }
        Node q = PartialOrder.NFR;
        int vn1 = 0;
        int vn2 = 0;
        while (q != null) {
            if (q.id.compareTo(nfr1) == 0) {
                vn1 = q.priority;
            }
            else if (q.id.compareTo(nfr2) == 0) {
                vn2 = q.priority;
            }
            q = q.next;
        }
        final String search = null;
        final PO temp = new PO();
        if (vn1 >= vn2) {
            temp.id1 = fr1;
            temp.id2 = fr2;
        }
        else {
            temp.id1 = fr2;
            temp.id2 = fr1;
        }
        if (PartialOrder.proot == null) {
            PartialOrder.proot = temp;
        }
        else {
            PO r;
            for (r = PartialOrder.proot; r.next != null; r = r.next) {}
            r.next = temp;
        }
    }
    
    public static void Pcase5(final String fr1, final String fr2) {
        System.out.println("Called Pcase5");
        int max = 0;
        String nfr = null;
        for (Node t = PartialOrder.LNFR1; t != null; t = t.next) {
            for (Node q = PartialOrder.NFR; q != null; q = q.next) {
                if (q.id.compareTo(t.id) == 0 && max <= q.priority) {
                    max = q.priority;
                    nfr = q.id;
                }
            }
        }
        for (Node t = PartialOrder.LNFR2; t != null; t = t.next) {
            for (Node q = PartialOrder.NFR; q != null; q = q.next) {
                if (q.id.compareTo(t.id) == 0 && max < q.priority) {
                    max = q.priority;
                    nfr = q.id;
                }
            }
        }
        int flag1 = 0;
        int flag2 = 0;
        int val1 = 0;
        int val2 = 0;
        for (BC bclist = PartialOrder.bcHead; bclist != null; bclist = bclist.next) {
            if (nfr.compareTo(bclist.Nid) == 0) {
                for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                    if (flist.id.compareTo(fr1) == 0) {
                        flag1 = 1;
                        val1 = flist.val;
                    }
                    else if (flist.id.compareTo(fr2) == 0) {
                        flag2 = 1;
                        val2 = flist.val;
                    }
                }
                break;
            }
        }
        final PO temp = new PO();
        if (flag1 == 1 && flag2 == 1) {
            if (val1 >= val2) {
                temp.id1 = fr1;
                temp.id2 = fr2;
            }
            else {
                temp.id1 = fr2;
                temp.id2 = fr1;
            }
            if (PartialOrder.proot == null) {
                PartialOrder.proot = temp;
            }
            else {
                PO r;
                for (r = PartialOrder.proot; r.next != null; r = r.next) {}
                r.next = temp;
            }
        }
        else {
            Pcase9(fr1, fr2);
        }
    }
    
    public static void Pcase6(final String fr1, final String fr2) {
        System.out.println("Called Pcase6");
        int countConflict = 0;
        Node n1 = PartialOrder.LNFR1;
        String nfr1 = null;
        String nfr2 = null;
        int max = 0;
        while (n1 != null) {
            for (Node n2 = PartialOrder.LNFR2; n2 != null; n2 = n2.next) {
                for (Edge1 conflict = PartialOrder.E_NN; conflict != null; conflict = conflict.next) {
                    if ((n1.id.compareTo(conflict.id1) == 0 && n2.id.compareTo(conflict.id2) == 0) || (n1.id.compareTo(conflict.id2) == 0 && n2.id.compareTo(conflict.id1) == 0)) {
                        if (max < conflict.value) {
                            max = conflict.value;
                            nfr1 = conflict.id1;
                            nfr2 = conflict.id2;
                        }
                        ++countConflict;
                    }
                }
            }
            n1 = n1.next;
        }
        if (countConflict > 0) {
            int val1 = 0;
            int val2 = 0;
            for (Node p = PartialOrder.NFR; p != null; p = p.next) {
                if (p.id.compareTo(nfr1) == 0) {
                    val1 = p.priority;
                }
                else if (p.id.compareTo(nfr2) == 0) {
                    val2 = p.priority;
                }
            }
            final PO temp = new PO();
            if (val1 >= val2) {
                int flag1 = 0;
                int flag2 = 0;
                int v1 = 0;
                int v2 = 0;
                for (BC bclist = PartialOrder.bcHead; bclist != null; bclist = bclist.next) {
                    if (nfr1.compareTo(bclist.Nid) == 0) {
                        for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                            if (flist.id.compareTo(fr1) == 0) {
                                flag1 = 1;
                                v1 = flist.val;
                            }
                            else if (flist.id.compareTo(fr2) == 0) {
                                flag2 = 1;
                                v2 = flist.val;
                            }
                        }
                        break;
                    }
                }
                if (flag1 == 1 && flag2 == 1) {
                    if (v1 >= v2) {
                        temp.id1 = fr1;
                        temp.id2 = fr2;
                    }
                    else {
                        temp.id1 = fr2;
                        temp.id2 = fr1;
                    }
                    if (PartialOrder.proot == null) {
                        PartialOrder.proot = temp;
                    }
                    else {
                        PO r;
                        for (r = PartialOrder.proot; r.next != null; r = r.next) {}
                        r.next = temp;
                    }
                }
            }
            else {
                int flag1 = 0;
                int flag2 = 0;
                int v1 = 0;
                int v2 = 0;
                for (BC bclist = PartialOrder.bcHead; bclist != null; bclist = bclist.next) {
                    if (nfr2.compareTo(bclist.Nid) == 0) {
                        for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                            if (flist.id.compareTo(fr1) == 0) {
                                flag1 = 1;
                                v1 = flist.val;
                            }
                            else if (flist.id.compareTo(fr2) == 0) {
                                flag2 = 1;
                                v2 = flist.val;
                            }
                        }
                        break;
                    }
                }
                System.out.println("In else v1=" + v1 + "v2= " + v2);
                if (flag1 == 1 && flag2 == 1) {
                    if (v1 >= v2) {
                        temp.id1 = fr1;
                        temp.id2 = fr2;
                    }
                    else {
                        temp.id1 = fr2;
                        temp.id2 = fr1;
                    }
                    if (PartialOrder.proot == null) {
                        PartialOrder.proot = temp;
                    }
                    else {
                        PO r;
                        for (r = PartialOrder.proot; r.next != null; r = r.next) {}
                        r.next = temp;
                    }
                }
                else {
                    Pcase9(fr1, fr2);
                }
            }
        }
        else {
            System.out.println("I am here");
            Pcase9(fr1, fr2);
        }
    }
    
    public static void Pcase7(final String fr1, final String fr2) {
        int countConflict = 0;
        for (Node n1 = PartialOrder.LNFR1; n1.next != null; n1 = n1.next) {
            for (Node n2 = n1.next; n2 != null; n2 = n2.next) {
                for (Edge1 conflict = PartialOrder.E_NN; conflict != null; conflict = conflict.next) {
                    if ((n1.id.compareTo(conflict.id1) == 0 && n2.id.compareTo(conflict.id2) == 0) || (n1.id.compareTo(conflict.id2) == 0 && n2.id.compareTo(conflict.id1) == 0)) {
                        ++countConflict;
                    }
                }
            }
        }
        if (countConflict > 0) {
            final int threshold = 40;
            MacroWeight mroot = null;
            for (Node n1 = PartialOrder.LNFR1; n1.next != null; n1 = n1.next) {
                for (Node n3 = n1.next; n3 != null; n3 = n3.next) {
                    for (Edge1 conflict2 = PartialOrder.E_NN; conflict2 != null; conflict2 = conflict2.next) {
                        if ((n1.id.compareTo(conflict2.id1) == 0 && n3.id.compareTo(conflict2.id2) == 0) || (n1.id.compareTo(conflict2.id2) == 0 && n3.id.compareTo(conflict2.id1) == 0)) {
                            final MacroWeight temp = new MacroWeight();
                            temp.id1 = n1.id;
                            temp.id2 = n3.id;
                            Node p = PartialOrder.NFR;
                            float sum = 0.0f;
                            while (p != null) {
                                if (p.id.compareTo(n1.id) == 0) {
                                    sum += p.priority;
                                }
                                else if (p.id.compareTo(n3.id) == 0) {
                                    sum += p.priority;
                                }
                                p = p.next;
                            }
                            sum /= 200.0f;
                            temp.val = (conflict2.value - threshold) * sum;
                            if (mroot == null) {
                                mroot = temp;
                            }
                            else {
                                MacroWeight m;
                                for (m = mroot; m.next != null; m = m.next) {}
                                m.next = temp;
                            }
                        }
                    }
                }
            }
            MacroWeight i = mroot;
            String nfr1 = null;
            String nfr2 = null;
            float max = 0.0f;
            while (i != null) {
                if (i.val >= max) {
                    max = i.val;
                    nfr1 = i.id1;
                    nfr2 = i.id2;
                }
                i = i.next;
            }
            Node p2 = PartialOrder.NFR;
            final int priority = 0;
            String maxNFR = null;
            while (p2 != null) {
                if (p2.id.compareTo(nfr1) == 0) {
                    if (priority < p2.priority) {
                        maxNFR = nfr1;
                    }
                }
                else if (p2.id.compareTo(nfr2) == 0 && priority < p2.priority) {
                    maxNFR = nfr2;
                }
                p2 = p2.next;
            }
            BC b = PartialOrder.bcHead;
            int val1 = 0;
            int val2 = 0;
            while (b != null) {
                if (b.Nid.compareTo(maxNFR) == 0) {
                    for (FRDep f = b.begin; f != null; f = f.next) {
                        if (f.id.compareTo(fr1) == 0) {
                            val1 = f.val;
                        }
                        else if (f.id.compareTo(fr2) == 0) {
                            val2 = f.val;
                        }
                    }
                }
                b = b.next;
            }
            final PO t = new PO();
            if (val1 >= val2) {
                t.id1 = fr1;
                t.id2 = fr2;
            }
            else {
                t.id1 = fr2;
                t.id2 = fr1;
            }
            if (PartialOrder.proot == null) {
                PartialOrder.proot = t;
            }
            else {
                PO s;
                for (s = PartialOrder.proot; s.next != null; s = s.next) {}
                s.next = t;
            }
        }
        else {
            Pcase1(fr1, fr2);
        }
    }
    
    public static void Pcase8(final String fr1, final String fr2) {
        final int threshold = 40;
        Node n1 = null;
        MacroWeight mroot = null;
        for (n1 = PartialOrder.LNFR1; n1 != null; n1 = n1.next) {
            for (Node n2 = PartialOrder.LNFR2; n2 != null; n2 = n2.next) {
                for (Edge1 conflict = PartialOrder.E_NN; conflict != null; conflict = conflict.next) {
                    if ((n1.id.compareTo(conflict.id1) == 0 && n2.id.compareTo(conflict.id2) == 0) || (n1.id.compareTo(conflict.id2) == 0 && n2.id.compareTo(conflict.id1) == 0)) {
                        final MacroWeight temp = new MacroWeight();
                        temp.id1 = n1.id;
                        temp.id2 = n2.id;
                        Node p = PartialOrder.NFR;
                        float sum = 0.0f;
                        while (p != null) {
                            if (p.id.compareTo(n1.id) == 0) {
                                sum += p.priority;
                            }
                            else if (p.id.compareTo(n2.id) == 0) {
                                sum += p.priority;
                            }
                            p = p.next;
                        }
                        sum /= 200.0f;
                        temp.val = (conflict.value - threshold) * sum;
                        if (mroot == null) {
                            mroot = temp;
                        }
                        else {
                            MacroWeight m;
                            for (m = mroot; m.next != null; m = m.next) {}
                            m.next = temp;
                        }
                    }
                }
            }
        }
        MacroWeight i = mroot;
        String nfr1 = null;
        String nfr2 = null;
        float max = 0.0f;
        while (i != null) {
            if (i.val >= max) {
                max = i.val;
                nfr1 = i.id1;
                nfr2 = i.id2;
            }
            i = i.next;
        }
        Node p2 = PartialOrder.NFR;
        int priority = 0;
        String maxNFR = null;
        while (p2 != null) {
            if (p2.id.compareTo(nfr1) == 0) {
                if (priority < p2.priority) {
                    maxNFR = nfr1;
                    priority = p2.priority;
                }
            }
            else if (p2.id.compareTo(nfr2) == 0 && priority < p2.priority) {
                maxNFR = nfr2;
                priority = p2.priority;
            }
            p2 = p2.next;
        }
        BC b = PartialOrder.bcHead;
        String fprecede = null;
        while (b != null) {
            if (b.Nid.compareTo(maxNFR) == 0) {
                for (FRDep f = b.begin; f != null; f = f.next) {
                    if (f.id.compareTo(fr1) == 0) {
                        fprecede = fr1;
                    }
                    else if (f.id.compareTo(fr2) == 0) {
                        fprecede = fr2;
                    }
                }
            }
            b = b.next;
        }
        final PO t = new PO();
        if (fprecede.compareTo(fr1) == 0) {
            t.id1 = fr1;
            t.id2 = fr2;
        }
        else {
            t.id1 = fr2;
            t.id2 = fr1;
        }
        if (PartialOrder.proot == null) {
            PartialOrder.proot = t;
        }
        else {
            PO s;
            for (s = PartialOrder.proot; s.next != null; s = s.next) {}
            s.next = t;
        }
    }
    
    public static void Pcase9(final String fr1, final String fr2) {
        System.out.println("Called Pcase9");
        Node l1 = PartialOrder.LNFR1;
        String maxNFR = null;
        int max = 0;
        while (l1 != null) {
            for (Node l2 = PartialOrder.LNFR2; l2 != null; l2 = l2.next) {
                if (l1.id.compareTo(l2.id) == 0) {
                    for (Node p = PartialOrder.NFR; p != null; p = p.next) {
                        if (p.id.compareTo(l1.id) == 0 && max < p.priority) {
                            max = p.priority;
                            maxNFR = p.id;
                            break;
                        }
                    }
                }
            }
            l1 = l1.next;
        }
        System.out.println("Selected NFR is" + maxNFR);
        BC bc = PartialOrder.bcHead;
        int val1 = 0;
        int val2 = 0;
        while (bc != null) {
            if (bc.Nid.compareTo(maxNFR) == 0) {
                for (FRDep s = bc.begin; s != null; s = s.next) {
                    if (s.id.compareTo(fr1) == 0) {
                        val1 = s.val;
                    }
                    else if (s.id.compareTo(fr2) == 0) {
                        val2 = s.val;
                    }
                }
            }
            bc = bc.next;
        }
        final PO temp = new PO();
        if (val1 >= val2) {
            temp.id1 = fr1;
            temp.id2 = fr2;
        }
        else {
            temp.id1 = fr2;
            temp.id2 = fr1;
        }
        if (PartialOrder.proot == null) {
            PartialOrder.proot = temp;
        }
        else {
            PO r;
            for (r = PartialOrder.proot; r.next != null; r = r.next) {}
            r.next = temp;
        }
        System.out.println("Done2");
    }
    
    public static void Pcase10(final String fr1, final String fr2) {
        int countConflict = 0;
        for (Node n1 = PartialOrder.LNFR1; n1 != null; n1 = n1.next) {
            for (Node n2 = PartialOrder.LNFR2; n2 != null; n2 = n2.next) {
                for (Edge1 conflict = PartialOrder.E_NN; conflict != null; conflict = conflict.next) {
                    if ((n1.id.compareTo(conflict.id1) == 0 && n2.id.compareTo(conflict.id2) == 0) || (n1.id.compareTo(conflict.id2) == 0 && n2.id.compareTo(conflict.id1) == 0)) {
                        ++countConflict;
                    }
                }
            }
        }
        if (countConflict > 0) {
            final int threshold = 40;
            MacroWeight mroot = null;
            for (Node p1 = PartialOrder.LNFR1; p1 != null; p1 = p1.next) {
                for (Node p2 = PartialOrder.LNFR2; p2 != null; p2 = p2.next) {
                    for (Edge1 conflict2 = PartialOrder.E_NN; conflict2 != null; conflict2 = conflict2.next) {
                        if ((p1.id.compareTo(conflict2.id1) == 0 && p2.id.compareTo(conflict2.id2) == 0) || (p1.id.compareTo(conflict2.id2) == 0 && p2.id.compareTo(conflict2.id1) == 0)) {
                            final MacroWeight temp = new MacroWeight();
                            temp.id1 = p1.id;
                            temp.id2 = p2.id;
                            Node p3 = PartialOrder.NFR;
                            float sum = 0.0f;
                            while (p3 != null) {
                                if (p3.id.compareTo(p1.id) == 0) {
                                    sum += p3.priority;
                                }
                                else if (p3.id.compareTo(p2.id) == 0) {
                                    sum += p3.priority;
                                }
                                p3 = p3.next;
                            }
                            sum /= 200.0f;
                            temp.val = (conflict2.value - threshold) * sum;
                            if (mroot == null) {
                                mroot = temp;
                            }
                            else {
                                MacroWeight m;
                                for (m = mroot; m.next != null; m = m.next) {}
                                m.next = temp;
                            }
                        }
                    }
                }
            }
            MacroWeight i = mroot;
            String nfr1 = null;
            String nfr2 = null;
            float max = 0.0f;
            while (i != null) {
                if (i.val >= max) {
                    max = i.val;
                    nfr1 = i.id1;
                    nfr2 = i.id2;
                }
                i = i.next;
            }
            Node p4 = PartialOrder.NFR;
            final int priority = 0;
            String maxNFR = null;
            while (p4 != null) {
                if (p4.id.compareTo(nfr1) == 0) {
                    if (priority < p4.priority) {
                        maxNFR = nfr1;
                    }
                }
                else if (p4.id.compareTo(nfr2) == 0 && priority < p4.priority) {
                    maxNFR = nfr2;
                }
                p4 = p4.next;
            }
            BC b = PartialOrder.bcHead;
            int val1 = 0;
            int val2 = 0;
            while (b != null) {
                if (b.Nid.compareTo(maxNFR) == 0) {
                    for (FRDep f = b.begin; f != null; f = f.next) {
                        if (f.id.compareTo(fr1) == 0) {
                            val1 = f.val;
                        }
                        else if (f.id.compareTo(fr2) == 0) {
                            val2 = f.val;
                        }
                    }
                }
                b = b.next;
            }
            final PO t = new PO();
            if (val1 >= val2) {
                t.id1 = fr1;
                t.id2 = fr2;
            }
            else {
                t.id1 = fr2;
                t.id2 = fr1;
            }
            if (PartialOrder.proot == null) {
                PartialOrder.proot = t;
            }
            else {
                PO s;
                for (s = PartialOrder.proot; s.next != null; s = s.next) {}
                s.next = t;
            }
        }
        else {
            Pcase5(fr1, fr2);
        }
    }
    
    public static void Pcase11(final String fr1, final String fr2) {
        int countConflict = 0;
        for (Node n1 = PartialOrder.LNFR1; n1 != null; n1 = n1.next) {
            for (Node n2 = PartialOrder.LNFR2; n2 != null; n2 = n2.next) {
                for (Edge1 conflict = PartialOrder.E_NN; conflict != null; conflict = conflict.next) {
                    if ((n1.id.compareTo(conflict.id1) == 0 && n2.id.compareTo(conflict.id2) == 0) || (n1.id.compareTo(conflict.id2) == 0 && n2.id.compareTo(conflict.id1) == 0)) {
                        ++countConflict;
                    }
                }
            }
        }
        if (countConflict > 0) {
            final int threshold = 40;
            MacroWeight mroot = null;
            final NFRWeight nroot = null;
            for (Node n1 = PartialOrder.LNFR1; n1 != null; n1 = n1.next) {
                for (Node n3 = PartialOrder.LNFR2; n3 != null; n3 = n3.next) {
                    for (Edge1 conflict2 = PartialOrder.E_NN; conflict2 != null; conflict2 = conflict2.next) {
                        if ((n1.id.compareTo(conflict2.id1) == 0 && n3.id.compareTo(conflict2.id2) == 0) || (n1.id.compareTo(conflict2.id2) == 0 && n3.id.compareTo(conflict2.id1) == 0)) {
                            final MacroWeight temp = new MacroWeight();
                            temp.id1 = n1.id;
                            temp.id2 = n3.id;
                            temp.val = conflict2.value * (float)PartialOrder.w1;
                            Node p = PartialOrder.NFR;
                            final NFRWeight temp2 = new NFRWeight();
                            final NFRWeight temp3 = new NFRWeight();
                            temp2.id = n1.id;
                            temp3.id = n3.id;
                            while (p != null) {
                                if (p.id.compareTo(n1.id) == 0) {
                                    temp2.val = p.priority * (float)PartialOrder.w2;
                                }
                                else if (p.id.compareTo(n3.id) == 0) {
                                    temp3.val = p.priority * (float)PartialOrder.w2;
                                }
                                p = p.next;
                            }
                            temp.val = temp.val + temp2.val + temp3.val;
                            if (mroot == null) {
                                mroot = temp;
                            }
                            else {
                                MacroWeight m;
                                for (m = mroot; m.next != null; m = m.next) {}
                                m.next = temp;
                            }
                        }
                    }
                }
            }
            MacroWeight i = mroot;
            String nfr1 = null;
            String nfr2 = null;
            final String nfr3 = null;
            float max1 = 0.0f;
            while (i != null) {
                if (i.val >= max1) {
                    max1 = i.val;
                    nfr1 = i.id1;
                    nfr2 = i.id2;
                }
                i = i.next;
            }
            Node p2 = PartialOrder.NFR;
            int priority = 0;
            String maxNFR = null;
            while (p2 != null) {
                if (p2.id.compareTo(nfr1) == 0) {
                    if (priority < p2.priority) {
                        priority = p2.priority;
                        maxNFR = nfr1;
                    }
                }
                else if (p2.id.compareTo(nfr2) == 0 && priority < p2.priority) {
                    priority = p2.priority;
                    maxNFR = nfr2;
                }
                p2 = p2.next;
            }
            BC b = PartialOrder.bcHead;
            int val1 = 0;
            int val2 = 0;
            while (b != null) {
                if (b.Nid.compareTo(maxNFR) == 0) {
                    for (FRDep f = b.begin; f != null; f = f.next) {
                        if (f.id.compareTo(fr1) == 0) {
                            val1 = f.val;
                        }
                        else if (f.id.compareTo(fr2) == 0) {
                            val2 = f.val;
                        }
                    }
                }
                b = b.next;
            }
            final PO t = new PO();
            if (val1 >= val2) {
                t.id1 = fr1;
                t.id2 = fr2;
            }
            else {
                t.id1 = fr2;
                t.id2 = fr1;
            }
            if (PartialOrder.proot == null) {
                PartialOrder.proot = t;
            }
            else {
                PO s;
                for (s = PartialOrder.proot; s.next != null; s = s.next) {}
                s.next = t;
            }
        }
        else {
            Pcase9(fr1, fr2);
        }
    }
    
    public static void display_PartialOrder() {
        PO p = PartialOrder.proot;
        System.out.println("The partial order is :");
        while (p != null) {
            System.out.println(String.valueOf(p.id1) + "->" + p.id2);
            p = p.next;
        }
    }
    
    public static void create_frame() {
        PartialOrder.frame1.getContentPane().setBackground(new Color(255, 229, 204));
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        }
        catch (Exception e) {
            System.out.println("Look and Feel not set");
        }
        PartialOrder.frame1.setLayout(null);
        PartialOrder.frame1.setDefaultCloseOperation(3);
        PartialOrder.frame1.setBounds(15, 6, 1000, 1000);
        (PartialOrder.label3 = new JLabel("Partial Order")).setFont(new Font("Calibri", 2, 20));
        PartialOrder.label3.setBounds(600, 430, 200, 40);
        PartialOrder.frame1.add(PartialOrder.label3);
        PartialOrder.scrollPane1.setVerticalScrollBarPolicy(22);
        PartialOrder.scrollPane1.setHorizontalScrollBarPolicy(32);
        PartialOrder.scrollPane1.setBounds(400, 480, 570, 400);
        PartialOrder.textOrder1.setFont(new Font("Calibri", 2, 20));
        PartialOrder.textOrder1.setEditable(false);
        PartialOrder.frame1.add(PartialOrder.scrollPane1);
        add_NFRTextBox();
        add_parameters();
        PartialOrder.generate.setFont(new Font("Calibri", 2, 16));
        PartialOrder.generate.setBackground(new Color(102, 102, 255));
        PartialOrder.generate.setForeground(Color.black);
        PartialOrder.generate.setBounds(400, 380, 300, 40);
        PartialOrder.frame1.add(PartialOrder.generate);
        PartialOrder.viewgraph.setFont(new Font("Calibri", 2, 16));
        PartialOrder.viewgraph.setBackground(new Color(102, 102, 255));
        PartialOrder.viewgraph.setForeground(Color.black);
        PartialOrder.viewgraph.setBounds(720, 380, 200, 40);
        PartialOrder.frame1.add(PartialOrder.viewgraph);
        PartialOrder.frame1.setVisible(true);
        PartialOrder.generate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                if (PartialOrder.choice == 0) {
                    JOptionPane.showMessageDialog(PartialOrder.frame1, "Select a parameter");
                }
                else {
                    PartialOrder.beginGeneration();
                }
            }
        });
        PartialOrder.viewgraph.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                if (PartialOrder.proot == null) {
                    JOptionPane.showMessageDialog(PartialOrder.frame1, "Generate Partial Order at first");
                }
                else {
                    if (PartialOrder.choice == 1) {
                        PartialOrder.drawGraphC();
                    }
                    else if (PartialOrder.choice == 2) {
                        PartialOrder.drawGraphP();
                    }
                    else if (PartialOrder.choice == 3) {
                        PartialOrder.drawGraphB1();
                    }
                    else if (PartialOrder.choice == 4) {
                        PartialOrder.drawGraphB2();
                    }
                    else if (PartialOrder.choice == 5) {
                        PartialOrder.drawGraphNC();
                    }
                    System.out.println("The edge count is: " + PartialOrder.edgeCount);
                }
            }
        });
    }
    
    public static void resolve2() {
        for (PO k = PartialOrder.proot; k != null; k = k.next) {
            final String s1 = k.id1;
            final String s2 = k.id2;
            for (PO j = PartialOrder.proot; j != null; j = j.next) {
                if (j.id1.compareTo(s1) == 0 && j.id2.compareTo(s2) != 0) {
                    final String s3 = j.id2;
                    PO i = PartialOrder.proot;
                    int flag = 0;
                    String s4 = null;
                    while (i != null) {
                        if (i.id1.compareTo(s3) == 0 && i.id2.compareTo(s2) == 0) {
                            flag = 1;
                            s4 = s3;
                        }
                        i = i.next;
                    }
                    if (flag == 1) {
                        PO n;
                        PO m = n = PartialOrder.proot;
                        while (m != null) {
                            if (m.id1.compareTo(s1) == 0 && m.id2.compareTo(s2) == 0) {
                                System.out.println("Found for " + s1 + " and " + s2 + " via " + s4);
                                if (m == PartialOrder.proot) {
                                    PartialOrder.proot = m.next;
                                    break;
                                }
                                n.next = m.next;
                                break;
                            }
                            else {
                                n = m;
                                m = m.next;
                            }
                        }
                    }
                }
            }
        }
    }
    
    public static void resolve() {
        PO b = PartialOrder.reachable;
        System.out.println("The reachable set is");
        while (b != null) {
            System.out.println(String.valueOf(b.id1) + "->" + b.id2);
            b = b.next;
        }
        for (plist v = PartialOrder.rlist; v != null; v = v.next) {
            for (sNode r = v.begin; r != null; r = r.next) {
                System.out.print(String.valueOf(r.id) + " " + r.flag);
                r.flag = 0;
            }
            System.out.println();
        }
        for (PO k = PartialOrder.reachable; k != null; k = k.next) {
            final String s1 = k.id1;
            final String s2 = k.id2;
            int flag = 0;
            for (PO j = PartialOrder.reachable; j != null; j = j.next) {
                if (j.id1.compareTo(s1) == 0 && j.id2.compareTo(s2) != 0) {
                    final String s3 = j.id2;
                    PO m = PartialOrder.reachable;
                    flag = 0;
                    while (m != null) {
                        if (m.id1.compareTo(s3) == 0 && m.id2.compareTo(s2) == 0) {
                            flag = 1;
                        }
                        m = m.next;
                    }
                    if (flag == 1) {
                        for (plist k2 = PartialOrder.rlist; k2 != null; k2 = k2.next) {
                            sNode f = k2.begin;
                            for (sNode p = f.next; p != null; p = p.next) {
                                if (f.id.compareTo(s1) == 0 && p.id.compareTo(s2) == 0) {
                                    System.out.println("Compairing" + s1 + " " + s2);
                                    System.out.println("Found via" + s1 + " " + s3 + "To " + s3 + " " + s2);
                                    System.out.println("Flagging" + s1 + " " + s2);
                                    p.flag = 1;
                                }
                                f = p;
                            }
                        }
                    }
                }
            }
        }
        System.out.println("in resolve");
        for (plist v = PartialOrder.rlist; v != null; v = v.next) {
            for (sNode r2 = v.begin; r2 != null; r2 = r2.next) {
                System.out.print(String.valueOf(r2.id) + " " + r2.flag);
            }
            System.out.println();
        }
    }
    
    public static void add_NFRTextBox() {
        (PartialOrder.label1 = new JLabel("Set NFR Priorities")).setFont(new Font("Calibri", 2, 20));
        PartialOrder.label1.setBounds(50, 10, 200, 40);
        PartialOrder.frame1.add(PartialOrder.label1);
        final int x = 50;
        int y = 50;
        Node name = PartialOrder.NFR;
        for (int i = 1; i <= PartialOrder.countNFR; ++i) {
            final String temp = name.id;
            (PartialOrder.NFRlabels[i] = new JLabel(temp)).setFont(new Font("Calibri", 2, 16));
            PartialOrder.NFRlabels[i].setBounds(x, y, 50, 50);
            PartialOrder.frame1.add(PartialOrder.NFRlabels[i]);
            (PartialOrder.NFRPriority[i] = new JTextField()).setBounds(x + 100, y, 100, 40);
            PartialOrder.NFRPriority[i].setText("");
            PartialOrder.frame1.add(PartialOrder.NFRPriority[i]);
            y += 50;
            name = name.next;
        }
        PartialOrder.savePriority.setFont(new Font("Calibri", 2, 16));
        PartialOrder.savePriority.setBackground(new Color(102, 102, 255));
        PartialOrder.savePriority.setForeground(Color.black);
        PartialOrder.savePriority.setBounds(x, y, 100, 40);
        PartialOrder.frame1.add(PartialOrder.savePriority);
        PartialOrder.savePriority.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                PartialOrder.setPriority();
            }
        });
    }
    
    public static void setPriority() {
        int flag = 0;
        for (int i = 1; i <= PartialOrder.countNFR; ++i) {
            if (PartialOrder.NFRPriority[i].getText().isEmpty()) {
                JOptionPane.showMessageDialog(PartialOrder.frame1, "Enter all the priorities");
                flag = 1;
                break;
            }
        }
        if (flag == 0) {
            Node p = PartialOrder.NFR;
            for (int j = 1; p != null; p = p.next, ++j) {
                final String temp = PartialOrder.NFRPriority[j].getText().toString();
                final int num = Integer.parseInt(temp);
                p.priority = num;
            }
        }
    }
    
    public static void add_parameters() {
        (PartialOrder.label2 = new JLabel("Select a Parameter")).setFont(new Font("Calibri", 2, 20));
        PartialOrder.label2.setBounds(380, 50, 200, 40);
        PartialOrder.frame1.add(PartialOrder.label2);
        (PartialOrder.label8 = new JLabel("Conflict")).setFont(new Font("Calibri", 2, 20));
        PartialOrder.label8.setBounds(380, 200, 200, 40);
        PartialOrder.frame1.add(PartialOrder.label8);
        (PartialOrder.label9 = new JLabel("NFR Priority")).setFont(new Font("Calibri", 2, 20));
        PartialOrder.label9.setBounds(760, 200, 200, 40);
        PartialOrder.frame1.add(PartialOrder.label9);
        final ButtonGroup buttonGroup = new ButtonGroup();
        buttonGroup.add(PartialOrder.conflict);
        buttonGroup.add(PartialOrder.priority);
        buttonGroup.add(PartialOrder.both);
        buttonGroup.add(PartialOrder.both2);
        buttonGroup.add(PartialOrder.nc);
        PartialOrder.conflict.setFont(new Font("Calibri", 2, 16));
        PartialOrder.conflict.setBounds(380, 100, 100, 40);
        PartialOrder.frame1.add(PartialOrder.conflict);
        PartialOrder.priority.setFont(new Font("Calibri", 2, 16));
        PartialOrder.priority.setBounds(530, 100, 130, 40);
        PartialOrder.frame1.add(PartialOrder.priority);
        PartialOrder.both.setFont(new Font("Calibri", 2, 16));
        PartialOrder.both.setBounds(680, 100, 130, 40);
        PartialOrder.frame1.add(PartialOrder.both);
        PartialOrder.both2.setFont(new Font("Calibri", 2, 16));
        PartialOrder.both2.setBounds(380, 150, 130, 40);
        PartialOrder.frame1.add(PartialOrder.both2);
        PartialOrder.nc.setFont(new Font("Calibri", 2, 16));
        PartialOrder.nc.setBounds(580, 150, 130, 40);
        PartialOrder.frame1.add(PartialOrder.nc);
        PartialOrder.slider1.setMajorTickSpacing(1);
        PartialOrder.slider1.setMinorTickSpacing(1);
        PartialOrder.slider1.setBackground(new Color(153, 204, 255));
        PartialOrder.slider1.setPaintLabels(true);
        PartialOrder.slider1.setPaintTicks(true);
        PartialOrder.slider1.setPreferredSize(new Dimension(230, 46));
        final Format f = new DecimalFormat("0.0");
        final Hashtable<Integer, JComponent> labels = new Hashtable<Integer, JComponent>();
        for (int i = 0; i <= 10; ++i) {
            final JLabel label = new JLabel(f.format(i * 0.1));
            label.setFont(new Font("Calibri", 1, 16));
            labels.put(i, label);
        }
        PartialOrder.slider1.setLabelTable(labels);
        PartialOrder.slider1.setBounds(450, 200, 300, 60);
        PartialOrder.frame1.add(PartialOrder.slider1);
        PartialOrder.submit.setFont(new Font("Calibri", 2, 16));
        PartialOrder.submit.setBounds(400, 300, 100, 40);
        PartialOrder.submit.setBackground(new Color(102, 102, 255));
        PartialOrder.submit.setForeground(Color.black);
        PartialOrder.frame1.add(PartialOrder.submit);
        PartialOrder.submit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                PartialOrder.setChoice();
            }
        });
    }
    
    public static void setChoice() {
        if (PartialOrder.conflict.isSelected()) {
            PartialOrder.choice = 1;
        }
        else if (PartialOrder.priority.isSelected()) {
            PartialOrder.choice = 2;
        }
        else if (PartialOrder.both.isSelected()) {
            PartialOrder.choice = 3;
        }
        else if (PartialOrder.both2.isSelected()) {
            PartialOrder.w1 = PartialOrder.slider1.getValue() / 10.0;
            PartialOrder.w2 = 1.0 - PartialOrder.w1;
            PartialOrder.choice = 4;
        }
        else if (PartialOrder.nc.isSelected()) {
            PartialOrder.choice = 5;
        }
        else {
            JOptionPane.showMessageDialog(PartialOrder.frame1, "Select a parameter");
        }
    }
    
    public static void beginGeneration() {
        PartialOrder.bcHead = null;
        PartialOrder.mcHead = null;
        PartialOrder.proot = null;
        PartialOrder.root = null;
        System.out.println("Starting generation");
        final long startTime = Instant.now().toEpochMilli();
        create_BasicClusters();
        display_BasicClusters();
        if (PartialOrder.choice != 5) {
            create_MacroClusters();
            display_MacroClusters();
        }
        create_requirementSet();
        generate_PartialOrderNew();
        System.out.println("Before removing cycle");
        display_PartialOrder();
        removeCycles();
        removeCycles();
        display_PartialOrder();
        System.out.println("After removing transitive edges");
        removeCycles();
        display_PartialOrder();
        final long endTime = Instant.now().toEpochMilli();
        final long timeElapsed = endTime - startTime;
        for (PO t = PartialOrder.proot; t != null; t = t.next) {
            t.visited = 0;
        }
        getSequenceNew();
        final int c = removeCycle2();
        if (c == 1) {
            for (PO t = PartialOrder.proot; t != null; t = t.next) {
                t.visited = 0;
            }
            getSequenceNew();
        }
        resolve();
        setOrderInFrame();
        final long afterUsedMem = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        final long actualMemUsed = afterUsedMem - PartialOrder.beforeUsedMem;
        System.out.println("Execution time in milliseconds: " + timeElapsed);
        System.out.println("Memory used in Bytes: " + actualMemUsed);
    }
    
    public static void getSequence() {
        BufferedWriter b1 = null;
        if (PartialOrder.choice == 1) {
            PartialOrder.textOrder1.append("Conflict");
            PartialOrder.textOrder1.append("\n");
        }
        else if (PartialOrder.choice == 2) {
            PartialOrder.textOrder1.append("NFR Priority");
            PartialOrder.textOrder1.append("\n");
        }
        else if (PartialOrder.choice == 3) {
            PartialOrder.textOrder1.append("Product");
            PartialOrder.textOrder1.append("\n");
        }
        else if (PartialOrder.choice == 4) {
            PartialOrder.textOrder1.append("Weighted Sum");
            PartialOrder.textOrder1.append("\n");
        }
        int complete = 0;
        try {
            b1 = new BufferedWriter(new FileWriter("sequence.txt", false));
            while (complete == 0) {
                sNode root = null;
                for (PO p = PartialOrder.proot; p != null; p = p.next) {
                    if (p.visited == 0) {
                        System.out.println("Looking for" + p.id1 + "->" + p.id2);
                        if (root == null) {
                            p.visited = 1;
                            final sNode temp1 = new sNode();
                            temp1.id = p.id1;
                            final sNode temp2 = new sNode();
                            temp2.id = p.id2;
                            temp1.next = temp2;
                            root = temp1;
                            temp1.prev = root;
                            temp2.prev = temp1;
                            root.prev = null;
                        }
                        else {
                            final String s1 = p.id1;
                            final String s2 = p.id2;
                            int found = 0;
                            sNode temp3;
                            for (temp3 = root; temp3 != null; temp3 = temp3.next) {
                                if (temp3.id.compareTo(s1) == 0) {
                                    found = 1;
                                    break;
                                }
                            }
                            System.out.println("Found =" + found);
                            int exists = 0;
                            if (temp3 != null && temp3.next != null && found == 1) {
                                sNode prev = temp3;
                                sNode k = temp3.next;
                                final String s3 = k.id;
                                int flag = 0;
                                while (k != null) {
                                    final String c1 = s2;
                                    final String c2 = k.id;
                                    System.out.println("Checking for " + c1 + " -> " + c2);
                                    PO r = PartialOrder.proot;
                                    flag = 0;
                                    while (r != null) {
                                        if (r.id1.compareTo(c1) == 0 && r.id2.compareTo(c2) == 0) {
                                            flag = 1;
                                            break;
                                        }
                                        if (r.id1.compareTo(c2) == 0 && r.id2.compareTo(c1) == 0) {
                                            exists = 1;
                                        }
                                        r = r.next;
                                    }
                                    if (flag == 1) {
                                        System.out.println("Found");
                                        final sNode node = new sNode();
                                        node.id = s2;
                                        node.next = k;
                                        prev.next = node;
                                        node.prev = prev;
                                        break;
                                    }
                                    prev = k;
                                    k = k.next;
                                }
                                if (exists == 1 && flag != 1) {
                                    sNode j;
                                    for (j = root; j.next != null; j = j.next) {}
                                    final sNode node2 = new sNode();
                                    node2.id = s2;
                                    j.next = node2;
                                    node2.prev = j;
                                }
                            }
                            else if (temp3 != null && temp3.next == null && found == 1) {
                                final sNode node3 = new sNode();
                                node3.id = s2;
                                temp3.next = node3;
                            }
                            if (found == 0) {
                                System.out.println("checking for the other one");
                                int check = 0;
                                sNode k;
                                sNode prev2;
                                for (k = (prev2 = root); k != null; k = k.next) {
                                    if (k.id.compareTo(s2) == 0) {
                                        check = 1;
                                        break;
                                    }
                                    prev2 = k;
                                }
                                if (check == 1) {
                                    if (k == root) {
                                        final sNode node4 = new sNode();
                                        node4.id = s1;
                                        node4.next = k;
                                        root = node4;
                                        node4.prev = root;
                                        root.prev = null;
                                    }
                                    else {
                                        int flag = 0;
                                        System.out.println("Hie Here!");
                                        sNode pt;
                                        sNode q = pt = prev2;
                                        System.out.println("q.id=" + q.id);
                                        while (q != null) {
                                            final String s4 = q.id;
                                            System.out.println("Edge " + s4 + " -> " + s1);
                                            flag = 0;
                                            for (PO t = PartialOrder.proot; t != null; t = t.next) {
                                                if (t.id1.compareTo(s4) == 0 && t.id2.compareTo(s1) == 0) {
                                                    flag = 1;
                                                    break;
                                                }
                                                if (t.id1.compareTo(s1) == 0 && t.id2.compareTo(s4) == 0) {
                                                    exists = 1;
                                                }
                                            }
                                            System.out.println("flag=" + flag);
                                            if (flag == 1) {
                                                System.out.println("Yes Flag");
                                                System.out.println("Pt value is" + pt.id);
                                                final sNode f = pt.next;
                                                final sNode node5 = new sNode();
                                                node5.id = s1;
                                                node5.next = f;
                                                pt.next = node5;
                                                f.prev = node5;
                                                node5.prev = pt;
                                                break;
                                            }
                                            pt = q;
                                            q = q.prev;
                                        }
                                        if (exists == 1 && flag != 1) {
                                            final sNode node6 = new sNode();
                                            node6.id = s1;
                                            final sNode g = root;
                                            node6.next = g;
                                            root = node6;
                                            node6.prev = root;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    System.out.println("end of checking");
                    for (sNode i = root; i != null; i = i.next) {
                        System.out.print(String.valueOf(i.id) + " ");
                    }
                    for (sNode v = root; v != null; v = v.next) {
                        final String t2 = v.id;
                        for (sNode h = root; h != null; h = h.next) {
                            final String t3 = h.id;
                            for (PO m = PartialOrder.proot; m != null; m = m.next) {
                                if (m.id1.compareTo(t2) == 0 && m.id2.compareTo(t3) == 0) {
                                    m.visited = 1;
                                    break;
                                }
                            }
                        }
                    }
                }
                int count = 0;
                for (PO s5 = PartialOrder.proot; s5 != null; s5 = s5.next) {
                    if (s5.visited == 0) {
                        ++count;
                    }
                }
                if (count == 0) {
                    complete = 1;
                }
                PO l = PartialOrder.proot;
                System.out.println("The sequence is");
                for (sNode t4 = root; t4 != null; t4 = t4.next) {
                    System.out.print(String.valueOf(t4.id) + " ");
                }
                while (l != null) {
                    final String fr1 = l.id1;
                    final String fr2 = l.id2;
                    sNode r2 = root;
                    int flag2 = 0;
                    int flag3 = 0;
                    while (r2 != null) {
                        if (r2.id.compareTo(fr1) == 0) {
                            flag2 = 1;
                        }
                        if (r2.id.compareTo(fr2) == 0) {
                            flag3 = 1;
                        }
                        r2 = r2.next;
                    }
                    if (flag2 == 1 && flag3 == 1) {
                        l.visited = 1;
                    }
                    l = l.next;
                }
                System.out.println("remaining edges:");
                for (PO g2 = PartialOrder.proot; g2 != null; g2 = g2.next) {
                    if (g2.visited == 0) {
                        System.out.println(String.valueOf(g2.id1) + " " + g2.id2);
                    }
                }
                for (sNode k2 = root; k2 != null; k2 = k2.next) {
                    b1.write(k2.id);
                    if (k2.next != null) {
                        b1.write(" ");
                    }
                }
                b1.newLine();
            }
            b1.close();
        }
        catch (IOException ex) {}
    }
    
    public static void getSequenceNew() {
        PartialOrder.reachable = null;
        PartialOrder.rlist = null;
        BufferedWriter b1 = null;
        int complete = 0;
        try {
            b1 = new BufferedWriter(new FileWriter("sequence.txt", false));
            while (complete == 0) {
                sNode root = null;
                for (PO p = PartialOrder.proot; p != null; p = p.next) {
                    if (p.visited == 0) {
                        System.out.println("Looking for" + p.id1 + "->" + p.id2);
                        if (root == null) {
                            System.out.println("root is null");
                            p.visited = 1;
                            final sNode temp1 = new sNode();
                            temp1.id = p.id1;
                            final sNode temp2 = new sNode();
                            temp2.id = p.id2;
                            temp1.next = temp2;
                            root = temp1;
                            temp1.prev = root;
                            temp2.prev = temp1;
                            temp1.prev = null;
                        }
                        else {
                            final String s1 = p.id1;
                            final String s2 = p.id2;
                            int found = 0;
                            sNode temp3;
                            for (temp3 = root; temp3 != null; temp3 = temp3.next) {
                                if (temp3.id.compareTo(s1) == 0) {
                                    found = 1;
                                    break;
                                }
                            }
                            System.out.println("Found value=" + found);
                            final int exists = 0;
                            if (temp3 != null && temp3.next != null && found == 1) {
                                final sNode prev = temp3;
                                sNode k = temp3.next;
                                final String s3 = k.id;
                                int flag1 = 0;
                                int flag2 = 0;
                                sNode hold = null;
                                if (k.next == null) {
                                    PO r = PartialOrder.proot;
                                    int d = 0;
                                    final String c1 = s2;
                                    final String c2 = k.id;
                                    while (r != null) {
                                        if (r.id1.compareTo(c2) == 0 && r.id2.compareTo(c1) == 0) {
                                            d = 1;
                                            break;
                                        }
                                        r = r.next;
                                    }
                                    if (d == 1) {
                                        final sNode te = new sNode();
                                        te.id = s2;
                                        k.next = te;
                                        te.prev = k;
                                        p.visited = 1;
                                    }
                                }
                                else {
                                    int entered = 0;
                                    while (k != null) {
                                        final String c3 = s2;
                                        final String c4 = k.id;
                                        final String c5 = k.prev.id;
                                        for (PO r2 = PartialOrder.proot; r2 != null; r2 = r2.next) {
                                            if (r2.id1.compareTo(c5) == 0 && r2.id2.compareTo(c3) == 0) {
                                                flag1 = 1;
                                                break;
                                            }
                                        }
                                        for (PO r2 = PartialOrder.proot; r2 != null; r2 = r2.next) {
                                            if (r2.id1.compareTo(c3) == 0 && r2.id2.compareTo(c4) == 0) {
                                                flag2 = 1;
                                                break;
                                            }
                                        }
                                        if (flag1 == 1 && flag2 == 1) {
                                            hold = k;
                                            break;
                                        }
                                        if (flag1 == 1 && flag2 == 0) {
                                            PO r2 = PartialOrder.proot;
                                            int d2 = 0;
                                            while (r2 != null) {
                                                if (r2.id1.compareTo(c4) == 0 && r2.id2.compareTo(c3) == 0) {
                                                    d2 = 1;
                                                    break;
                                                }
                                                r2 = r2.next;
                                            }
                                            if (d2 != 1) {
                                                break;
                                            }
                                            if (k.next == null) {
                                                final sNode node = new sNode();
                                                node.id = s2;
                                                k.next = node;
                                                node.prev = k;
                                                entered = 1;
                                                p.visited = 1;
                                                break;
                                            }
                                            k = k.next;
                                        }
                                        else {
                                            k = k.next;
                                        }
                                    }
                                    if (hold != null && entered == 0) {
                                        final sNode node2 = new sNode();
                                        node2.id = s2;
                                        node2.next = hold;
                                        final sNode t = hold.prev;
                                        t.next = node2;
                                        node2.prev = t;
                                        hold.prev = node2;
                                        p.visited = 1;
                                    }
                                }
                            }
                            else if (temp3 != null && temp3.next == null && found == 1) {
                                final sNode node3 = new sNode();
                                node3.id = s2;
                                temp3.next = node3;
                                node3.prev = temp3;
                                p.visited = 1;
                            }
                            if (found == 0) {
                                System.out.println("checking for the other one");
                                int check = 0;
                                sNode prev2;
                                sNode k = prev2 = root;
                                int entered2 = 0;
                                while (k != null) {
                                    if (k.id.compareTo(s2) == 0) {
                                        check = 1;
                                        break;
                                    }
                                    prev2 = k;
                                    k = k.next;
                                }
                                if (check == 1) {
                                    if (k.prev == null) {
                                        final sNode node4 = new sNode();
                                        node4.id = s1;
                                        node4.next = k;
                                        k.prev = node4;
                                        root = node4;
                                        node4.prev = null;
                                        root.prev = null;
                                        p.visited = 1;
                                    }
                                    else {
                                        final int flag3 = 0;
                                        System.out.println("Hie Here!");
                                        final sNode pt;
                                        sNode q = pt = k;
                                        sNode hold2 = null;
                                        int d3 = 0;
                                        while (q != null) {
                                            final String c5 = q.id;
                                            final String c6 = s1;
                                            final String c7 = q.prev.id;
                                            int flag4 = 0;
                                            int flag5 = 0;
                                            for (PO t2 = PartialOrder.proot; t2 != null; t2 = t2.next) {
                                                if (t2.id1.compareTo(c6) == 0 && t2.id2.compareTo(c5) == 0) {
                                                    flag4 = 1;
                                                }
                                                else if (t2.id1.compareTo(c7) == 0 && t2.id2.compareTo(c6) == 0) {
                                                    flag5 = 1;
                                                }
                                            }
                                            System.out.println("flag1=" + flag4 + "flag2=" + flag5);
                                            if (flag4 == 1 && flag5 == 1) {
                                                hold2 = q;
                                                break;
                                            }
                                            if (flag5 == 0 && flag4 == 1) {
                                                d3 = 0;
                                                for (PO t2 = PartialOrder.proot; t2 != null; t2 = t2.next) {
                                                    if (t2.id1.compareTo(c6) == 0 && t2.id2.compareTo(c7) == 0) {
                                                        d3 = 1;
                                                        break;
                                                    }
                                                }
                                                if (d3 != 1) {
                                                    break;
                                                }
                                                final sNode h = q.prev;
                                                if (h.prev == null) {
                                                    final sNode te2 = new sNode();
                                                    te2.id = s1;
                                                    te2.next = h;
                                                    h.prev = te2;
                                                    root = te2;
                                                    te2.prev = null;
                                                    entered2 = 1;
                                                    p.visited = 1;
                                                    break;
                                                }
                                                q = q.prev;
                                            }
                                            else {
                                                q = q.prev;
                                            }
                                        }
                                        if (hold2 != null && entered2 == 0) {
                                            final sNode node5 = new sNode();
                                            node5.id = s1;
                                            final sNode g = hold2.prev;
                                            node5.next = hold2;
                                            g.next = node5;
                                            node5.prev = g;
                                            hold2.prev = node5;
                                            p.visited = 1;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    final sNode j = root;
                    for (sNode v = root; v != null; v = v.next) {
                        final String t3 = v.id;
                        for (sNode h2 = v.next; h2 != null; h2 = h2.next) {
                            final String t4 = h2.id;
                            for (PO m = PartialOrder.proot; m != null; m = m.next) {
                                if ((m.id1.compareTo(t3) == 0 && m.id2.compareTo(t4) == 0) || (m.id1.compareTo(t4) == 0 && m.id2.compareTo(t3) == 0)) {
                                    m.visited = 1;
                                    break;
                                }
                            }
                        }
                    }
                }
                for (sNode v2 = root; v2 != null; v2 = v2.next) {
                    final String t5 = v2.id;
                    for (sNode h3 = v2.next; h3 != null; h3 = h3.next) {
                        final String t6 = h3.id;
                        for (PO i = PartialOrder.proot; i != null; i = i.next) {
                            if ((i.id1.compareTo(t5) == 0 && i.id2.compareTo(t6) == 0) || (i.id1.compareTo(t6) == 0 && i.id2.compareTo(t5) == 0)) {
                                i.id1 = t5;
                                i.id2 = t6;
                                break;
                            }
                        }
                    }
                }
                for (sNode h4 = root; h4 != null; h4 = h4.next) {
                    for (sNode g2 = h4.next; g2 != null; g2 = g2.next) {
                        final PO node6 = new PO();
                        node6.id1 = h4.id;
                        node6.id2 = g2.id;
                        node6.visited = 0;
                        if (PartialOrder.reachable == null) {
                            PartialOrder.reachable = node6;
                        }
                        else {
                            PO l = PartialOrder.reachable;
                            int fl = 0;
                            while (l != null) {
                                if (l.id1.compareTo(h4.id) == 0 && l.id2.compareTo(g2.id) == 0) {
                                    fl = 1;
                                }
                                l = l.next;
                            }
                            if (fl == 0) {
                                for (l = PartialOrder.reachable; l.next != null; l = l.next) {}
                                l.next = node6;
                                node6.visited = 0;
                            }
                        }
                    }
                }
                int count = 0;
                for (PO s4 = PartialOrder.proot; s4 != null; s4 = s4.next) {
                    if (s4.visited == 0) {
                        ++count;
                    }
                }
                if (count == 0) {
                    complete = 1;
                }
                PO l = PartialOrder.proot;
                System.out.println("The sequence is");
                for (sNode t7 = root; t7 != null; t7 = t7.next) {
                    System.out.print(String.valueOf(t7.id) + " ");
                }
                sNode n = root;
                sNode t8 = null;
                while (n != null) {
                    final sNode node7 = new sNode();
                    node7.id = n.id;
                    node7.flag = 0;
                    if (t8 == null) {
                        t8 = node7;
                    }
                    else {
                        sNode t9;
                        for (t9 = t8; t9.next != null; t9 = t9.next) {}
                        t9.next = node7;
                    }
                    n = n.next;
                }
                if (PartialOrder.rlist == null) {
                    if (t8 != null) {
                        final plist node8 = new plist();
                        node8.begin = t8;
                        PartialOrder.rlist = node8;
                    }
                }
                else if (t8 != null) {
                    final plist node8 = new plist();
                    node8.begin = t8;
                    plist i2;
                    for (i2 = PartialOrder.rlist; i2.next != null; i2 = i2.next) {}
                    i2.next = node8;
                }
                while (l != null) {
                    final String fr1 = l.id1;
                    final String fr2 = l.id2;
                    sNode r3 = root;
                    int flag6 = 0;
                    int flag7 = 0;
                    while (r3 != null) {
                        if (r3.id.compareTo(fr1) == 0) {
                            flag6 = 1;
                        }
                        if (r3.id.compareTo(fr2) == 0) {
                            flag7 = 1;
                        }
                        r3 = r3.next;
                    }
                    if (flag6 == 1 && flag7 == 1) {
                        l.visited = 1;
                    }
                    l = l.next;
                }
                System.out.println("remaining edges:");
                for (PO g3 = PartialOrder.proot; g3 != null; g3 = g3.next) {
                    if (g3.visited == 0) {
                        System.out.println(String.valueOf(g3.id1) + " " + g3.id2);
                    }
                }
                for (sNode k2 = root; k2 != null; k2 = k2.next) {
                    b1.write(k2.id);
                    if (k2.next != null) {
                        b1.write(" ");
                    }
                }
                b1.newLine();
            }
            for (PO m2 = PartialOrder.reachable; m2 != null; m2 = m2.next) {
                System.out.println(String.valueOf(m2.id1) + "->" + m2.id2 + " count =" + m2.visited);
            }
            System.out.println("after generating sequences");
            for (plist h5 = PartialOrder.rlist; h5 != null; h5 = h5.next) {
                for (sNode k3 = h5.begin; k3 != null; k3 = k3.next) {
                    System.out.print(String.valueOf(k3.id) + " " + k3.flag);
                }
                System.out.println();
            }
            b1.close();
        }
        catch (IOException ex) {}
    }
    
    public static void setOrderInFrame() {
        if (PartialOrder.choice == 1) {
            PartialOrder.textOrder1.append("Conflict");
            PartialOrder.textOrder1.append("\n");
        }
        else if (PartialOrder.choice == 2) {
            PartialOrder.textOrder1.append("NFR Priority");
            PartialOrder.textOrder1.append("\n");
        }
        else if (PartialOrder.choice == 3) {
            PartialOrder.textOrder1.append("Product");
            PartialOrder.textOrder1.append("\n");
        }
        else if (PartialOrder.choice == 4) {
            PartialOrder.textOrder1.append("Weighted Sum");
            PartialOrder.textOrder1.append("\n");
        }
        else if (PartialOrder.choice == 5) {
            PartialOrder.textOrder1.append("Without considering NFR conflict");
            PartialOrder.textOrder1.append("\n");
        }
        plist m = PartialOrder.rlist;
        while (m != null) {
            for (sNode n = m.begin; n != null; n = n.next) {
                String temp;
                if (n.next != null) {
                    temp = String.valueOf(n.id) + "->";
                }
                else {
                    temp = n.id;
                }
                PartialOrder.textOrder1.append(temp);
            }
            m = m.next;
            PartialOrder.textOrder1.append("\n");
        }
    }
    
    public static void drawOrder() {
        PO p = PartialOrder.proot;
        final String temp = null;
        int fcount = 0;
        while (p != null) {
            if (PartialOrder.droot != null) {
                final String t1 = p.id1;
                final String t2 = p.id2;
                DrawNode d = PartialOrder.droot;
                int flag1 = 0;
                int flag2 = 0;
                while (d != null) {
                    if (d.name.compareTo(t1) == 0) {
                        flag1 = 1;
                    }
                    else if (d.name.compareTo(t2) == 0) {
                        flag2 = 1;
                    }
                    d = d.next;
                }
                if (flag1 == 0 && flag2 == 0) {
                    final DrawNode d2 = new DrawNode();
                    d2.name = p.id1;
                    final DrawNode d3 = new DrawNode();
                    d3.name = p.id2;
                    DrawNode s;
                    for (s = PartialOrder.droot; s.next != null; s = s.next) {}
                    s.next = d2;
                    s = s.next;
                    s.next = d3;
                    fcount += 2;
                }
                else if (flag1 == 0) {
                    final DrawNode d2 = new DrawNode();
                    d2.name = p.id1;
                    DrawNode s2;
                    for (s2 = PartialOrder.droot; s2.next != null; s2 = s2.next) {}
                    s2.next = d2;
                    ++fcount;
                }
                else if (flag2 == 0) {
                    final DrawNode d2 = new DrawNode();
                    d2.name = p.id2;
                    DrawNode s2;
                    for (s2 = PartialOrder.droot; s2.next != null; s2 = s2.next) {}
                    s2.next = d2;
                    ++fcount;
                }
            }
            else {
                final DrawNode d4 = new DrawNode();
                d4.name = p.id1;
                PartialOrder.droot = d4;
                final DrawNode d5 = new DrawNode();
                d5.name = p.id2;
                PartialOrder.droot.next = d5;
                fcount += 2;
            }
            p = p.next;
        }
        for (DrawNode d6 = PartialOrder.droot; d6 != null; d6 = d6.next) {
            int count = 0;
            for (PO t3 = PartialOrder.proot; t3 != null; t3 = t3.next) {
                if (t3.id2.compareTo(d6.name) == 0) {
                    ++count;
                }
            }
            d6.indegree = count;
        }
        final JLabel[] list = new JLabel[fcount];
        final int i = 0;
        int flag3 = 0;
        int x = 300;
        int y = 500;
        while (flag3 == 0) {
            int max = 0;
            DrawNode node = PartialOrder.droot;
            String label = null;
            String neigh = null;
            while (node != null) {
                if (max <= node.indegree && node.visited == 0) {
                    max = node.indegree;
                    label = node.name;
                }
                node = node.next;
            }
            PO pt = PartialOrder.proot;
            int visited = 0;
            while (pt != null) {
                if (pt.id2.compareTo(label) == 0) {
                    neigh = pt.id1;
                    for (node = PartialOrder.droot; node != null; node = node.next) {
                        if (node.name.compareTo(neigh) == 0 && node.visited == 1) {
                            x = node.x;
                            y = node.y;
                            visited = 1;
                        }
                    }
                }
                else if (pt.id1.compareTo(label) == 0) {
                    neigh = pt.id2;
                    for (node = PartialOrder.droot; node != null; node = node.next) {
                        if (node.name.compareTo(neigh) == 0 && node.visited == 1) {
                            x = node.x;
                            y = node.y;
                            visited = 1;
                        }
                    }
                }
                pt = pt.next;
            }
            if (visited == 1) {
                x += 20;
                y += 20;
                for (node = PartialOrder.droot; node != null && node.name.compareTo(label) != 0; node = node.next) {}
                if (node.visited == 0) {
                    node.x = x;
                    node.y = y;
                    node.visited = 1;
                }
            }
            else {
                x -= 40;
                y -= 40;
                for (node = PartialOrder.droot; node != null && node.name.compareTo(label) != 0; node = node.next) {}
                if (node.visited == 0) {
                    node.x = x;
                    node.y = y;
                    node.visited = 1;
                }
            }
            pt = PartialOrder.proot;
            int interchange = 0;
            while (pt != null) {
                if (pt.id2.compareTo(label) == 0) {
                    neigh = pt.id1;
                    for (node = PartialOrder.droot; node != null; node = node.next) {
                        if (node.name.compareTo(neigh) == 0 && node.visited == 0) {
                            if (interchange == 0) {
                                x += 20;
                                interchange = 1;
                            }
                            else {
                                y += 20;
                                interchange = 0;
                            }
                            node.x = x;
                            node.y = y;
                            node.visited = 1;
                            break;
                        }
                    }
                    System.out.println("x=" + x + " y=" + y);
                }
                else if (pt.id1.compareTo(label) == 0) {
                    neigh = pt.id2;
                    System.out.println("Found neighbor :" + neigh);
                    for (node = PartialOrder.droot; node != null; node = node.next) {
                        if (node.name.compareTo(neigh) == 0 && node.visited == 0) {
                            if (interchange == 0) {
                                x += 20;
                                y -= 20;
                                interchange = 1;
                            }
                            else {
                                x -= 20;
                                y += 20;
                                interchange = 0;
                            }
                            node.x = x;
                            node.y = y;
                            node.visited = 1;
                            break;
                        }
                    }
                    System.out.println("x=" + x + " y=" + y);
                }
                pt = pt.next;
            }
            node = PartialOrder.droot;
            flag3 = 1;
            while (node != null) {
                if (node.visited == 0) {
                    flag3 = 0;
                    break;
                }
                node = node.next;
            }
        }
        for (DrawNode d6 = PartialOrder.droot; d6 != null; d6 = d6.next) {
            System.out.println("FR: " + d6.name + "with in-degree" + d6.indegree);
            System.out.println("With locus x= " + d6.x + " y= " + d6.y);
        }
    }
    
    @Override
    public void paint(final Graphics g) {
        super.paint(g);
        g.drawOval(100, 100, 50, 40);
        g.drawOval(25, 25, 50, 50);
        g.drawOval(30, 30, 40, 40);
    }
    
    public static void drawGraphNC() {
        PartialOrder.edgeCount = 0;
        PartialOrder.checkEdge = null;
        PO edgeList = null;
        System.setProperty("org.graphstream.ui.renderer", "org.graphstream.ui.j2dviewer.J2DGraphRenderer");
        sNode p = null;
        for (PO q = PartialOrder.proot; q != null; q = q.next) {
            int flag1 = 0;
            int flag2 = 0;
            for (sNode t = p; t != null; t = t.next) {
                if (t.id.compareTo(q.id1) == 0) {
                    flag1 = 1;
                }
            }
            if (flag1 == 0) {
                final sNode temp = new sNode();
                temp.id = q.id1;
                temp.visited = 0;
                if (p == null) {
                    p = temp;
                }
                else {
                    sNode t;
                    for (t = p; t.next != null; t = t.next) {}
                    t.next = temp;
                }
            }
            for (sNode t = p; t != null; t = t.next) {
                if (t.id.compareTo(q.id2) == 0) {
                    flag2 = 1;
                }
            }
            if (flag2 == 0) {
                final sNode temp = new sNode();
                temp.id = q.id2;
                temp.visited = 0;
                if (p == null) {
                    p = temp;
                }
                else {
                    sNode t;
                    for (t = p; t.next != null; t = t.next) {}
                    t.next = temp;
                }
            }
        }
        for (sNode j = p; j != null; j = j.next) {
            System.out.println("jid=" + j.id);
        }
        final Graph graph = new MultiGraph("Parameter: No Conflict");
        graph.setAttribute("ui.title", "Parameter: No Conflict");
        graph.setAttribute("ui.stylesheet", "node {size : 40px; shape: circle;fill-color: yellow;text-mode:normal; text-alignment: center; text-background-mode: none; fill-mode: dyn-plain; text-visibility-mode: normal;}");
        sNode t = p;
        final PO po = PartialOrder.proot;
        for (plist m = PartialOrder.rlist; m != null; m = m.next) {
            sNode n = m.begin;
            for (sNode t2 = n.next; t2 != null; t2 = t2.next) {
                if (t2.flag == 0) {
                    for (sNode k = p; k != null; k = k.next) {
                        if (k.id.compareTo(n.id) == 0 && k.visited == 0) {
                            graph.addNode(k.id);
                            k.visited = 1;
                        }
                        if (k.id.compareTo(t2.id) == 0 && k.visited == 0) {
                            graph.addNode(k.id);
                            k.visited = 1;
                        }
                    }
                    final String s1 = n.id;
                    final String s2 = t2.id;
                    PO s3 = PartialOrder.reachable;
                    int add = 0;
                    while (s3 != null) {
                        if (s3.id1.compareTo(s1) == 0 && s3.id2.compareTo(s2) == 0 && s3.visited == 0) {
                            add = 1;
                            break;
                        }
                        s3 = s3.next;
                    }
                    if (add == 1) {
                        final String ed = String.valueOf(s1) + s2;
                        final PO temp2 = new PO();
                        temp2.id1 = s1;
                        temp2.id2 = s2;
                        if (edgeList == null) {
                            edgeList = temp2;
                        }
                        else {
                            PO r;
                            for (r = edgeList; r.next != null; r = r.next) {}
                            r.next = temp2;
                        }
                    }
                    n = t2;
                }
                else {
                    plist g = PartialOrder.rlist;
                    int c = 0;
                    final int flag3 = 0;
                    while (g != null) {
                        for (sNode b = g.begin; b != null; b = b.next) {
                            if (b.id.compareTo(t2.id) == 0 && b != g.begin && b.flag == 0) {
                                ++c;
                            }
                        }
                        g = g.next;
                    }
                    if (c == 0 && t2.next != null) {
                        final PO temp3 = new PO();
                        temp3.id1 = t2.id;
                        temp3.id2 = t2.next.id;
                        System.out.println("added extra 1" + temp3.id1 + "->" + temp3.id2);
                        if (edgeList == null) {
                            edgeList = temp3;
                        }
                        else {
                            PO r2;
                            for (r2 = edgeList; r2.next != null; r2 = r2.next) {}
                            r2.next = temp3;
                        }
                    }
                    else if (t2.next == null && c == 0) {
                        PO r3;
                        for (r3 = edgeList; r3.next != null; r3 = r3.next) {}
                        final String v = r3.id2;
                        final PO temp4 = new PO();
                        temp4.id1 = v;
                        temp4.id2 = t2.id;
                        System.out.println("added extra 2" + temp4.id1 + "->" + temp4.id2);
                        if (edgeList == null) {
                            edgeList = temp4;
                        }
                        else {
                            for (r3 = edgeList; r3.next != null; r3 = r3.next) {}
                            r3.next = temp4;
                        }
                    }
                }
            }
            for (sNode set = m.begin; set != null; set = set.next) {
                for (sNode set2 = set.next; set2 != null; set2 = set2.next) {
                    PO s4 = PartialOrder.reachable;
                    final int add2 = 0;
                    final String s5 = set.id;
                    final String s6 = set2.id;
                    while (s4 != null) {
                        if (s4.id1.compareTo(s5) == 0 && s4.id2.compareTo(s6) == 0 && s4.visited == 0) {
                            s4.visited = 1;
                        }
                        s4 = s4.next;
                    }
                }
            }
        }
        for (PO p2 = edgeList; p2 != null; p2 = p2.next) {
            final String s7 = p2.id2;
            final String s8 = p2.id1;
            for (PO q2 = edgeList; q2 != null; q2 = q2.next) {
                if (q2.id1.compareTo(s7) == 0) {
                    final String s2 = q2.id2;
                    PO prev;
                    PO i = prev = edgeList;
                    while (i != null) {
                        if (i.id1.compareTo(s2) == 0 && i.id2.compareTo(s8) == 0) {
                            System.out.println("First edge: " + s8 + " -> " + s7);
                            System.out.println("Second edge: " + s7 + " -> " + s2);
                            System.out.println("Third edge: " + s2 + " -> " + s8);
                            if (i != PartialOrder.proot) {
                                i = i.next;
                                prev.next = i;
                                break;
                            }
                            break;
                        }
                        else {
                            prev = i;
                            i = i.next;
                        }
                    }
                }
            }
        }
        for (PO p2 = edgeList; p2 != null; p2 = p2.next) {
            for (sNode r4 = p; r4 != null; r4 = r4.next) {
                if (r4.id.compareTo(p2.id1) == 0 && r4.visited == 0) {
                    r4.visited = 1;
                    graph.addNode(p2.id1);
                }
                if (r4.id.compareTo(p2.id2) == 0 && r4.visited == 0) {
                    r4.visited = 1;
                    graph.addNode(p2.id2);
                }
            }
            final String ed2 = String.valueOf(p2.id1) + p2.id2;
            ++PartialOrder.edgeCount;
            final Edge edge = graph.addEdge(ed2, p2.id1, p2.id2, true);
            edge.addAttribute("layout.weight", 6);
        }
        for (final org.graphstream.graph.Node node : graph) {
            node.addAttribute("ui.label", node.getId());
            node.addAttribute("layout.weight", 150);
        }
        graph.display();
    }
    
    public static void drawGraphP() {
        PartialOrder.edgeCount = 0;
        PartialOrder.checkEdge = null;
        PO edgeList = null;
        System.setProperty("org.graphstream.ui.renderer", "org.graphstream.ui.j2dviewer.J2DGraphRenderer");
        sNode p = null;
        for (PO q = PartialOrder.proot; q != null; q = q.next) {
            int flag1 = 0;
            int flag2 = 0;
            for (sNode t = p; t != null; t = t.next) {
                if (t.id.compareTo(q.id1) == 0) {
                    flag1 = 1;
                }
            }
            if (flag1 == 0) {
                final sNode temp = new sNode();
                temp.id = q.id1;
                temp.visited = 0;
                if (p == null) {
                    p = temp;
                }
                else {
                    sNode t;
                    for (t = p; t.next != null; t = t.next) {}
                    t.next = temp;
                }
            }
            for (sNode t = p; t != null; t = t.next) {
                if (t.id.compareTo(q.id2) == 0) {
                    flag2 = 1;
                }
            }
            if (flag2 == 0) {
                final sNode temp = new sNode();
                temp.id = q.id2;
                temp.visited = 0;
                if (p == null) {
                    p = temp;
                }
                else {
                    sNode t;
                    for (t = p; t.next != null; t = t.next) {}
                    t.next = temp;
                }
            }
        }
        for (sNode j = p; j != null; j = j.next) {
            System.out.println("jid=" + j.id);
        }
        final Graph graph = new MultiGraph("Parameter: NFR Priority");
        graph.setAttribute("ui.title", "Parameter: NFR Priority");
        graph.setAttribute("ui.stylesheet", "node {size : 40px; shape: circle;fill-color: yellow;text-mode:normal; text-alignment: center; text-background-mode: none; fill-mode: dyn-plain; text-visibility-mode: normal;}");
        sNode t = p;
        final PO po = PartialOrder.proot;
        for (plist m = PartialOrder.rlist; m != null; m = m.next) {
            sNode n = m.begin;
            for (sNode t2 = n.next; t2 != null; t2 = t2.next) {
                if (t2.flag == 0) {
                    for (sNode k = p; k != null; k = k.next) {
                        if (k.id.compareTo(n.id) == 0 && k.visited == 0) {
                            graph.addNode(k.id);
                            k.visited = 1;
                        }
                        if (k.id.compareTo(t2.id) == 0 && k.visited == 0) {
                            graph.addNode(k.id);
                            k.visited = 1;
                        }
                    }
                    final String s1 = n.id;
                    final String s2 = t2.id;
                    PO s3 = PartialOrder.reachable;
                    int add = 0;
                    while (s3 != null) {
                        if (s3.id1.compareTo(s1) == 0 && s3.id2.compareTo(s2) == 0 && s3.visited == 0) {
                            add = 1;
                            break;
                        }
                        s3 = s3.next;
                    }
                    if (add == 1) {
                        final String ed = String.valueOf(s1) + s2;
                        final PO temp2 = new PO();
                        temp2.id1 = s1;
                        temp2.id2 = s2;
                        if (edgeList == null) {
                            edgeList = temp2;
                        }
                        else {
                            PO r;
                            for (r = edgeList; r.next != null; r = r.next) {}
                            r.next = temp2;
                        }
                    }
                    n = t2;
                }
                else {
                    plist g = PartialOrder.rlist;
                    int c = 0;
                    final int flag3 = 0;
                    while (g != null) {
                        for (sNode b = g.begin; b != null; b = b.next) {
                            if (b.id.compareTo(t2.id) == 0 && b != g.begin && b.flag == 0) {
                                ++c;
                            }
                        }
                        g = g.next;
                    }
                    if (c == 0 && t2.next != null) {
                        final PO temp3 = new PO();
                        temp3.id1 = t2.id;
                        temp3.id2 = t2.next.id;
                        System.out.println("added extra 1" + temp3.id1 + "->" + temp3.id2);
                        if (edgeList == null) {
                            edgeList = temp3;
                        }
                        else {
                            PO r2;
                            for (r2 = edgeList; r2.next != null; r2 = r2.next) {}
                            r2.next = temp3;
                        }
                    }
                    else if (t2.next == null && c == 0) {
                        PO r3;
                        for (r3 = edgeList; r3.next != null; r3 = r3.next) {}
                        final String v = r3.id2;
                        final PO temp4 = new PO();
                        temp4.id1 = v;
                        temp4.id2 = t2.id;
                        System.out.println("added extra 2" + temp4.id1 + "->" + temp4.id2);
                        if (edgeList == null) {
                            edgeList = temp4;
                        }
                        else {
                            for (r3 = edgeList; r3.next != null; r3 = r3.next) {}
                            r3.next = temp4;
                        }
                    }
                }
            }
            for (sNode set = m.begin; set != null; set = set.next) {
                for (sNode set2 = set.next; set2 != null; set2 = set2.next) {
                    PO s4 = PartialOrder.reachable;
                    final int add2 = 0;
                    final String s5 = set.id;
                    final String s6 = set2.id;
                    while (s4 != null) {
                        if (s4.id1.compareTo(s5) == 0 && s4.id2.compareTo(s6) == 0 && s4.visited == 0) {
                            s4.visited = 1;
                        }
                        s4 = s4.next;
                    }
                }
            }
        }
        for (PO p2 = edgeList; p2 != null; p2 = p2.next) {
            final String s7 = p2.id2;
            final String s8 = p2.id1;
            for (PO q2 = edgeList; q2 != null; q2 = q2.next) {
                if (q2.id1.compareTo(s7) == 0) {
                    final String s2 = q2.id2;
                    PO prev;
                    PO i = prev = edgeList;
                    while (i != null) {
                        if (i.id1.compareTo(s2) == 0 && i.id2.compareTo(s8) == 0) {
                            System.out.println("First edge: " + s8 + " -> " + s7);
                            System.out.println("Second edge: " + s7 + " -> " + s2);
                            System.out.println("Third edge: " + s2 + " -> " + s8);
                            if (i != PartialOrder.proot) {
                                i = i.next;
                                prev.next = i;
                                break;
                            }
                            break;
                        }
                        else {
                            prev = i;
                            i = i.next;
                        }
                    }
                }
            }
        }
        for (PO p2 = edgeList; p2 != null; p2 = p2.next) {
            for (sNode r4 = p; r4 != null; r4 = r4.next) {
                if (r4.id.compareTo(p2.id1) == 0 && r4.visited == 0) {
                    r4.visited = 1;
                    graph.addNode(p2.id1);
                }
                if (r4.id.compareTo(p2.id2) == 0 && r4.visited == 0) {
                    r4.visited = 1;
                    graph.addNode(p2.id2);
                }
            }
            final String ed2 = String.valueOf(p2.id1) + p2.id2;
            ++PartialOrder.edgeCount;
            final Edge edge = graph.addEdge(ed2, p2.id1, p2.id2, true);
            edge.addAttribute("layout.weight", 6);
        }
        for (final org.graphstream.graph.Node node : graph) {
            node.addAttribute("ui.label", node.getId());
            node.addAttribute("layout.weight", 150);
        }
        graph.display();
    }
    
    public static void drawGraphC() {
        PartialOrder.edgeCount = 0;
        PartialOrder.checkEdge = null;
        PO edgeList = null;
        System.setProperty("org.graphstream.ui.renderer", "org.graphstream.ui.j2dviewer.J2DGraphRenderer");
        sNode p = null;
        for (PO q = PartialOrder.proot; q != null; q = q.next) {
            int flag1 = 0;
            int flag2 = 0;
            for (sNode t = p; t != null; t = t.next) {
                if (t.id.compareTo(q.id1) == 0) {
                    flag1 = 1;
                }
            }
            if (flag1 == 0) {
                final sNode temp = new sNode();
                temp.id = q.id1;
                temp.visited = 0;
                if (p == null) {
                    p = temp;
                }
                else {
                    sNode t;
                    for (t = p; t.next != null; t = t.next) {}
                    t.next = temp;
                }
            }
            for (sNode t = p; t != null; t = t.next) {
                if (t.id.compareTo(q.id2) == 0) {
                    flag2 = 1;
                }
            }
            if (flag2 == 0) {
                final sNode temp = new sNode();
                temp.id = q.id2;
                temp.visited = 0;
                if (p == null) {
                    p = temp;
                }
                else {
                    sNode t;
                    for (t = p; t.next != null; t = t.next) {}
                    t.next = temp;
                }
            }
        }
        for (sNode j = p; j != null; j = j.next) {
            System.out.println("jid=" + j.id);
        }
        final Graph graph = new MultiGraph("Parameter: NFR Conflict");
        graph.setAttribute("ui.title", "Parameter: NFR Conflict");
        graph.setAttribute("ui.stylesheet", "node {size : 40px; shape: circle;fill-color: yellow;text-mode:normal; text-alignment: center; text-background-mode: none; fill-mode: dyn-plain; text-visibility-mode: normal;}");
        sNode t = p;
        final PO po = PartialOrder.proot;
        for (plist m = PartialOrder.rlist; m != null; m = m.next) {
            sNode n = m.begin;
            for (sNode t2 = n.next; t2 != null; t2 = t2.next) {
                if (t2.flag == 0) {
                    for (sNode k = p; k != null; k = k.next) {
                        if (k.id.compareTo(n.id) == 0 && k.visited == 0) {
                            graph.addNode(k.id);
                            k.visited = 1;
                        }
                        if (k.id.compareTo(t2.id) == 0 && k.visited == 0) {
                            graph.addNode(k.id);
                            k.visited = 1;
                        }
                    }
                    final String s1 = n.id;
                    final String s2 = t2.id;
                    PO s3 = PartialOrder.reachable;
                    int add = 0;
                    while (s3 != null) {
                        if (s3.id1.compareTo(s1) == 0 && s3.id2.compareTo(s2) == 0 && s3.visited == 0) {
                            add = 1;
                            break;
                        }
                        s3 = s3.next;
                    }
                    if (add == 1) {
                        final String ed = String.valueOf(s1) + s2;
                        final PO temp2 = new PO();
                        temp2.id1 = s1;
                        temp2.id2 = s2;
                        if (edgeList == null) {
                            edgeList = temp2;
                        }
                        else {
                            PO r;
                            for (r = edgeList; r.next != null; r = r.next) {}
                            r.next = temp2;
                        }
                    }
                    n = t2;
                }
                else {}
            }
            for (sNode set = m.begin; set != null; set = set.next) {
                for (sNode set2 = set.next; set2 != null; set2 = set2.next) {
                    PO s4 = PartialOrder.reachable;
                    final int add2 = 0;
                    final String s5 = set.id;
                    final String s6 = set2.id;
                    while (s4 != null) {
                        if (s4.id1.compareTo(s5) == 0 && s4.id2.compareTo(s6) == 0 && s4.visited == 0) {
                            s4.visited = 1;
                        }
                        s4 = s4.next;
                    }
                }
            }
        }
        for (PO p2 = edgeList; p2 != null; p2 = p2.next) {
            final String s7 = p2.id2;
            final String s8 = p2.id1;
            for (PO q2 = edgeList; q2 != null; q2 = q2.next) {
                if (q2.id1.compareTo(s7) == 0) {
                    final String s2 = q2.id2;
                    PO prev;
                    PO i = prev = edgeList;
                    while (i != null) {
                        if (i.id1.compareTo(s2) == 0 && i.id2.compareTo(s8) == 0) {
                            System.out.println("First edge: " + s8 + " -> " + s7);
                            System.out.println("Second edge: " + s7 + " -> " + s2);
                            System.out.println("Third edge: " + s2 + " -> " + s8);
                            if (i != PartialOrder.proot) {
                                i = i.next;
                                prev.next = i;
                                break;
                            }
                            break;
                        }
                        else {
                            prev = i;
                            i = i.next;
                        }
                    }
                }
            }
        }
        for (PO p2 = edgeList; p2 != null; p2 = p2.next) {
            for (sNode r2 = p; r2 != null; r2 = r2.next) {
                if (r2.id.compareTo(p2.id1) == 0 && r2.visited == 0) {
                    r2.visited = 1;
                    graph.addNode(p2.id1);
                }
                if (r2.id.compareTo(p2.id2) == 0 && r2.visited == 0) {
                    r2.visited = 1;
                    graph.addNode(p2.id2);
                }
            }
            final String ed2 = String.valueOf(p2.id1) + p2.id2;
            ++PartialOrder.edgeCount;
            final Edge edge = graph.addEdge(ed2, p2.id1, p2.id2, true);
            edge.addAttribute("layout.weight", 6);
        }
        for (final org.graphstream.graph.Node node : graph) {
            node.addAttribute("ui.label", node.getId());
            node.addAttribute("layout.weight", 150);
        }
        graph.display();
    }
    
    public static void drawGraphB1() {
        PartialOrder.edgeCount = 0;
        PartialOrder.checkEdge = null;
        PO edgeList = null;
        System.setProperty("org.graphstream.ui.renderer", "org.graphstream.ui.j2dviewer.J2DGraphRenderer");
        sNode p = null;
        for (PO q = PartialOrder.proot; q != null; q = q.next) {
            int flag1 = 0;
            int flag2 = 0;
            for (sNode t = p; t != null; t = t.next) {
                if (t.id.compareTo(q.id1) == 0) {
                    flag1 = 1;
                }
            }
            if (flag1 == 0) {
                final sNode temp = new sNode();
                temp.id = q.id1;
                temp.visited = 0;
                if (p == null) {
                    p = temp;
                }
                else {
                    sNode t;
                    for (t = p; t.next != null; t = t.next) {}
                    t.next = temp;
                }
            }
            for (sNode t = p; t != null; t = t.next) {
                if (t.id.compareTo(q.id2) == 0) {
                    flag2 = 1;
                }
            }
            if (flag2 == 0) {
                final sNode temp = new sNode();
                temp.id = q.id2;
                temp.visited = 0;
                if (p == null) {
                    p = temp;
                }
                else {
                    sNode t;
                    for (t = p; t.next != null; t = t.next) {}
                    t.next = temp;
                }
            }
        }
        for (sNode j = p; j != null; j = j.next) {
            System.out.println("jid=" + j.id);
        }
        final Graph graph = new MultiGraph("Parameter: Product");
        graph.setAttribute("ui.title", "Parameter: Product");
        graph.setAttribute("ui.stylesheet", "node {size : 40px; shape: circle;fill-color: yellow;text-mode:normal; text-alignment: center; text-background-mode: none; fill-mode: dyn-plain; text-visibility-mode: normal;}");
        sNode t = p;
        final PO po = PartialOrder.proot;
        for (plist m = PartialOrder.rlist; m != null; m = m.next) {
            sNode n = m.begin;
            for (sNode t2 = n.next; t2 != null; t2 = t2.next) {
                if (t2.flag == 0) {
                    for (sNode k = p; k != null; k = k.next) {
                        if (k.id.compareTo(n.id) == 0 && k.visited == 0) {
                            graph.addNode(k.id);
                            k.visited = 1;
                        }
                        if (k.id.compareTo(t2.id) == 0 && k.visited == 0) {
                            graph.addNode(k.id);
                            k.visited = 1;
                        }
                    }
                    final String s1 = n.id;
                    final String s2 = t2.id;
                    PO s3 = PartialOrder.reachable;
                    int add = 0;
                    while (s3 != null) {
                        if (s3.id1.compareTo(s1) == 0 && s3.id2.compareTo(s2) == 0 && s3.visited == 0) {
                            add = 1;
                            break;
                        }
                        s3 = s3.next;
                    }
                    if (add == 1) {
                        final String ed = String.valueOf(s1) + s2;
                        final PO temp2 = new PO();
                        temp2.id1 = s1;
                        temp2.id2 = s2;
                        if (edgeList == null) {
                            edgeList = temp2;
                        }
                        else {
                            PO r;
                            for (r = edgeList; r.next != null; r = r.next) {}
                            r.next = temp2;
                        }
                    }
                    n = t2;
                }
                else {
                    plist g = PartialOrder.rlist;
                    int c = 0;
                    final int flag3 = 0;
                    while (g != null) {
                        for (sNode b = g.begin; b != null; b = b.next) {
                            if (b.id.compareTo(t2.id) == 0 && b != g.begin && b.flag == 0) {
                                ++c;
                            }
                        }
                        g = g.next;
                    }
                    if (c == 0 && t2.next != null) {
                        final PO temp3 = new PO();
                        temp3.id1 = t2.id;
                        temp3.id2 = t2.next.id;
                        System.out.println("added extra 1" + temp3.id1 + "->" + temp3.id2);
                        if (edgeList == null) {
                            edgeList = temp3;
                        }
                        else {
                            PO r2;
                            for (r2 = edgeList; r2.next != null; r2 = r2.next) {}
                            r2.next = temp3;
                        }
                    }
                    else if (t2.next == null && c == 0) {
                        PO r3;
                        for (r3 = edgeList; r3.next != null; r3 = r3.next) {}
                        final String v = r3.id2;
                        final PO temp4 = new PO();
                        temp4.id1 = v;
                        temp4.id2 = t2.id;
                        System.out.println("added extra 2" + temp4.id1 + "->" + temp4.id2);
                        if (edgeList == null) {
                            edgeList = temp4;
                        }
                        else {
                            for (r3 = edgeList; r3.next != null; r3 = r3.next) {}
                            r3.next = temp4;
                        }
                    }
                }
            }
            for (sNode set = m.begin; set != null; set = set.next) {
                for (sNode set2 = set.next; set2 != null; set2 = set2.next) {
                    PO s4 = PartialOrder.reachable;
                    final int add2 = 0;
                    final String s5 = set.id;
                    final String s6 = set2.id;
                    while (s4 != null) {
                        if (s4.id1.compareTo(s5) == 0 && s4.id2.compareTo(s6) == 0 && s4.visited == 0) {
                            s4.visited = 1;
                        }
                        s4 = s4.next;
                    }
                }
            }
        }
        for (PO p2 = edgeList; p2 != null; p2 = p2.next) {
            final String s7 = p2.id2;
            final String s8 = p2.id1;
            for (PO q2 = edgeList; q2 != null; q2 = q2.next) {
                if (q2.id1.compareTo(s7) == 0) {
                    final String s2 = q2.id2;
                    PO prev;
                    PO i = prev = edgeList;
                    while (i != null) {
                        if (i.id1.compareTo(s2) == 0 && i.id2.compareTo(s8) == 0) {
                            System.out.println("First edge: " + s8 + " -> " + s7);
                            System.out.println("Second edge: " + s7 + " -> " + s2);
                            System.out.println("Third edge: " + s2 + " -> " + s8);
                            if (i != PartialOrder.proot) {
                                i = i.next;
                                prev.next = i;
                                break;
                            }
                            break;
                        }
                        else {
                            prev = i;
                            i = i.next;
                        }
                    }
                }
            }
        }
        for (PO p2 = edgeList; p2 != null; p2 = p2.next) {
            for (sNode r4 = p; r4 != null; r4 = r4.next) {
                if (r4.id.compareTo(p2.id1) == 0 && r4.visited == 0) {
                    r4.visited = 1;
                    graph.addNode(p2.id1);
                }
                if (r4.id.compareTo(p2.id2) == 0 && r4.visited == 0) {
                    r4.visited = 1;
                    graph.addNode(p2.id2);
                }
            }
            final String ed2 = String.valueOf(p2.id1) + p2.id2;
            ++PartialOrder.edgeCount;
            final Edge edge = graph.addEdge(ed2, p2.id1, p2.id2, true);
            edge.addAttribute("layout.weight", 6);
        }
        for (final org.graphstream.graph.Node node : graph) {
            node.addAttribute("ui.label", node.getId());
            node.addAttribute("layout.weight", 150);
        }
        graph.display();
    }
    
    public static void drawGraphB2() {
        PartialOrder.edgeCount = 0;
        PartialOrder.checkEdge = null;
        PO edgeList = null;
        System.setProperty("org.graphstream.ui.renderer", "org.graphstream.ui.j2dviewer.J2DGraphRenderer");
        sNode p = null;
        for (PO q = PartialOrder.proot; q != null; q = q.next) {
            int flag1 = 0;
            int flag2 = 0;
            for (sNode t = p; t != null; t = t.next) {
                if (t.id.compareTo(q.id1) == 0) {
                    flag1 = 1;
                }
            }
            if (flag1 == 0) {
                final sNode temp = new sNode();
                temp.id = q.id1;
                temp.visited = 0;
                if (p == null) {
                    p = temp;
                }
                else {
                    sNode t;
                    for (t = p; t.next != null; t = t.next) {}
                    t.next = temp;
                }
            }
            for (sNode t = p; t != null; t = t.next) {
                if (t.id.compareTo(q.id2) == 0) {
                    flag2 = 1;
                }
            }
            if (flag2 == 0) {
                final sNode temp = new sNode();
                temp.id = q.id2;
                temp.visited = 0;
                if (p == null) {
                    p = temp;
                }
                else {
                    sNode t;
                    for (t = p; t.next != null; t = t.next) {}
                    t.next = temp;
                }
            }
        }
        for (sNode j = p; j != null; j = j.next) {
            System.out.println("jid=" + j.id);
        }
        final Graph graph = new MultiGraph("Parameter: Weighted Sum");
        graph.setAttribute("ui.title", "Parameter: Weighted Sum");
        graph.setAttribute("ui.stylesheet", "node {size : 40px; shape: circle;fill-color: yellow;text-mode:normal; text-alignment: center; text-background-mode: none; fill-mode: dyn-plain; text-visibility-mode: normal;}");
        sNode t = p;
        final PO po = PartialOrder.proot;
        for (plist m = PartialOrder.rlist; m != null; m = m.next) {
            sNode n = m.begin;
            for (sNode t2 = n.next; t2 != null; t2 = t2.next) {
                if (t2.flag == 0) {
                    for (sNode k = p; k != null; k = k.next) {
                        if (k.id.compareTo(n.id) == 0 && k.visited == 0) {
                            graph.addNode(k.id);
                            k.visited = 1;
                        }
                        if (k.id.compareTo(t2.id) == 0 && k.visited == 0) {
                            graph.addNode(k.id);
                            k.visited = 1;
                        }
                    }
                    final String s1 = n.id;
                    final String s2 = t2.id;
                    PO s3 = PartialOrder.reachable;
                    int add = 0;
                    while (s3 != null) {
                        if (s3.id1.compareTo(s1) == 0 && s3.id2.compareTo(s2) == 0 && s3.visited == 0) {
                            add = 1;
                            break;
                        }
                        s3 = s3.next;
                    }
                    if (add == 1) {
                        final String ed = String.valueOf(s1) + s2;
                        final PO temp2 = new PO();
                        temp2.id1 = s1;
                        temp2.id2 = s2;
                        if (edgeList == null) {
                            edgeList = temp2;
                        }
                        else {
                            PO r;
                            for (r = edgeList; r.next != null; r = r.next) {}
                            r.next = temp2;
                        }
                    }
                    n = t2;
                }
                else {
                    plist g = PartialOrder.rlist;
                    int c = 0;
                    final int flag3 = 0;
                    while (g != null) {
                        for (sNode b = g.begin; b != null; b = b.next) {
                            if (b.id.compareTo(t2.id) == 0 && b != g.begin && b.flag == 0) {
                                ++c;
                            }
                        }
                        g = g.next;
                    }
                    if (c == 0 && t2.next != null) {
                        final PO temp3 = new PO();
                        temp3.id1 = t2.id;
                        temp3.id2 = t2.next.id;
                        System.out.println("added extra 1" + temp3.id1 + "->" + temp3.id2);
                        if (edgeList == null) {
                            edgeList = temp3;
                        }
                        else {
                            PO r2;
                            for (r2 = edgeList; r2.next != null; r2 = r2.next) {}
                            r2.next = temp3;
                        }
                    }
                    else if (t2.next == null && c == 0) {
                        PO r3;
                        for (r3 = edgeList; r3.next != null; r3 = r3.next) {}
                        final String v = r3.id2;
                        final PO temp4 = new PO();
                        temp4.id1 = v;
                        temp4.id2 = t2.id;
                        System.out.println("added extra 2" + temp4.id1 + "->" + temp4.id2);
                        if (edgeList == null) {
                            edgeList = temp4;
                        }
                        else {
                            for (r3 = edgeList; r3.next != null; r3 = r3.next) {}
                            r3.next = temp4;
                        }
                    }
                }
            }
            for (sNode set = m.begin; set != null; set = set.next) {
                for (sNode set2 = set.next; set2 != null; set2 = set2.next) {
                    PO s4 = PartialOrder.reachable;
                    final int add2 = 0;
                    final String s5 = set.id;
                    final String s6 = set2.id;
                    while (s4 != null) {
                        if (s4.id1.compareTo(s5) == 0 && s4.id2.compareTo(s6) == 0 && s4.visited == 0) {
                            s4.visited = 1;
                        }
                        s4 = s4.next;
                    }
                }
            }
        }
        for (PO p2 = edgeList; p2 != null; p2 = p2.next) {
            final String s7 = p2.id2;
            final String s8 = p2.id1;
            for (PO q2 = edgeList; q2 != null; q2 = q2.next) {
                if (q2.id1.compareTo(s7) == 0) {
                    final String s2 = q2.id2;
                    PO prev;
                    PO i = prev = edgeList;
                    while (i != null) {
                        if (i.id1.compareTo(s2) == 0 && i.id2.compareTo(s8) == 0) {
                            System.out.println("First edge: " + s8 + " -> " + s7);
                            System.out.println("Second edge: " + s7 + " -> " + s2);
                            System.out.println("Third edge: " + s2 + " -> " + s8);
                            if (i != PartialOrder.proot) {
                                i = i.next;
                                prev.next = i;
                                break;
                            }
                            break;
                        }
                        else {
                            prev = i;
                            i = i.next;
                        }
                    }
                }
            }
        }
        for (PO p2 = edgeList; p2 != null; p2 = p2.next) {
            for (sNode r4 = p; r4 != null; r4 = r4.next) {
                if (r4.id.compareTo(p2.id1) == 0 && r4.visited == 0) {
                    r4.visited = 1;
                    graph.addNode(p2.id1);
                }
                if (r4.id.compareTo(p2.id2) == 0 && r4.visited == 0) {
                    r4.visited = 1;
                    graph.addNode(p2.id2);
                }
            }
            final String ed2 = String.valueOf(p2.id1) + p2.id2;
            ++PartialOrder.edgeCount;
            final Edge edge = graph.addEdge(ed2, p2.id1, p2.id2, true);
            edge.addAttribute("layout.weight", 6);
        }
        for (final org.graphstream.graph.Node node : graph) {
            node.addAttribute("ui.label", node.getId());
            node.addAttribute("layout.weight", 150);
        }
        graph.display();
    }
    
    public static void resolveLoop() {
        System.out.println("begin check for loop");
        PO p = PartialOrder.proot;
        String fr1 = null;
        String fr2 = null;
        while (p != null) {
            if (p.next == null) {
                fr1 = p.id1;
                fr2 = p.id2;
                break;
            }
            p = p.next;
        }
        int loop = 0;
        String search = fr2;
        while (loop != 1) {
            PO temp = PartialOrder.proot;
            int found = 0;
            System.out.println("Searching for" + search);
            while (temp != null) {
                if (temp.id1.compareTo(search) == 0) {
                    found = 1;
                    search = temp.id2;
                }
                temp = temp.next;
            }
            if (found == 0) {
                break;
            }
            if (search.compareTo(fr1) != 0) {
                continue;
            }
            loop = 1;
        }
        if (loop == 1) {
            PO p2 = PartialOrder.proot;
            for (PO q = p2.next; q.next != null; q = p2.next) {
                p2 = p2.next;
            }
            p2.next = null;
        }
        System.out.println("End check for loop");
    }
}
